const { query } = require('../db/pool');

async function list({ depot_id, article_id } = {}) {
  const params = [];
  const where = [];
  if (depot_id) { params.push(depot_id); where.push(`s.depot_id = $${params.length}`); }
  if (article_id) { params.push(article_id); where.push(`s.article_id = $${params.length}`); }
  const { rows } = await query(
    `SELECT s.*,
            a.code AS article_code, a.designation AS article_designation,
            d.code AS depot_code, d.nom AS depot_nom
       FROM stock_balances s
       JOIN articles a ON a.id = s.article_id
       JOIN depots d ON d.id = s.depot_id
       ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY a.code, d.code`,
    params,
  );
  return rows;
}

module.exports = { list };
