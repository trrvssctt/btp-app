const { query } = require('../db/pool');

async function list() {
  const { rows } = await query(`SELECT * FROM depots ORDER BY code`);
  return rows;
}

module.exports = { list };
