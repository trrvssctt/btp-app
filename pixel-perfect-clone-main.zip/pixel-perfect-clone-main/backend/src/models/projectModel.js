const { query } = require('../db/pool');

async function list() {
  const { rows } = await query(
    `SELECT p.*, COALESCE(s.count, 0)::int AS sites_count
       FROM projects p
       LEFT JOIN (SELECT project_id, COUNT(*) FROM sites GROUP BY project_id) s
              ON s.project_id = p.id
      ORDER BY p.created_at DESC`,
  );
  return rows;
}

async function findById(id) {
  const { rows } = await query(`SELECT * FROM projects WHERE id = $1`, [id]);
  return rows[0] || null;
}

async function listSites(projectId) {
  const { rows } = await query(
    `SELECT * FROM sites WHERE project_id = $1 ORDER BY code`,
    [projectId],
  );
  return rows;
}

async function create(p) {
  const { rows } = await query(
    `INSERT INTO projects(code, nom, client, budget_initial, statut, date_debut, date_fin)
     VALUES ($1,$2,$3,$4,COALESCE($5,'ACTIF'),$6,$7) RETURNING *`,
    [p.code, p.nom, p.client, p.budget_initial, p.statut, p.date_debut, p.date_fin],
  );
  return rows[0];
}

async function update(id, p) {
  const { rows } = await query(
    `UPDATE projects SET nom=$2, client=$3, budget_initial=$4, statut=$5,
            date_debut=$6, date_fin=$7, updated_at=now()
       WHERE id=$1 RETURNING *`,
    [id, p.nom, p.client, p.budget_initial, p.statut, p.date_debut, p.date_fin],
  );
  return rows[0] || null;
}

async function remove(id) {
  await query(`DELETE FROM projects WHERE id = $1`, [id]);
}

module.exports = { list, findById, listSites, create, update, remove };
