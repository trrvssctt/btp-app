const { query } = require('../db/pool');

async function list({ search } = {}) {
  const params = [];
  let where = 'WHERE a.actif = true';
  if (search) {
    params.push(`%${search}%`);
    where += ` AND (a.code ILIKE $${params.length} OR a.designation ILIKE $${params.length})`;
  }
  const { rows } = await query(
    `SELECT a.*, f.libelle AS famille, u.code AS unite
       FROM articles a
       LEFT JOIN article_families f ON f.id = a.famille_id
       LEFT JOIN units u ON u.id = a.unite_id
      ${where}
      ORDER BY a.code`,
    params,
  );
  return rows;
}

async function findById(id) {
  const { rows } = await query(`SELECT * FROM articles WHERE id = $1`, [id]);
  return rows[0] || null;
}

async function create(a) {
  const { rows } = await query(
    `INSERT INTO articles(code, designation, famille_id, unite_id, nature, prix_moyen, seuil_min)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [a.code, a.designation, a.famille_id, a.unite_id, a.nature, a.prix_moyen, a.seuil_min],
  );
  return rows[0];
}

module.exports = { list, findById, create };
