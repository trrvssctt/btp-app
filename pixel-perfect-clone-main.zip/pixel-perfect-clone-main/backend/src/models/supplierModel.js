const { query } = require('../db/pool');

async function list() {
  const { rows } = await query(`SELECT * FROM suppliers WHERE actif = true ORDER BY raison_sociale`);
  return rows;
}

module.exports = { list };
