const { query, withTransaction } = require('../db/pool');

async function list({ statut, project_id, requester_id } = {}) {
  const params = [];
  const where = [];
  if (statut) { params.push(statut); where.push(`r.statut = $${params.length}`); }
  if (project_id) { params.push(project_id); where.push(`r.project_id = $${params.length}`); }
  if (requester_id) { params.push(requester_id); where.push(`r.requester_id = $${params.length}`); }

  const { rows } = await query(
    `SELECT r.*,
            u.nom AS requester_nom,
            p.code AS project_code, p.nom AS project_nom,
            s.code AS site_code, s.nom AS site_nom,
            COALESCE(l.count, 0)::int AS lignes_count
       FROM requests r
       JOIN users u ON u.id = r.requester_id
       JOIN projects p ON p.id = r.project_id
       JOIN sites s ON s.id = r.site_id
       LEFT JOIN (SELECT request_id, COUNT(*) FROM request_lines GROUP BY request_id) l
              ON l.request_id = r.id
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY r.created_at DESC`,
    params,
  );
  return rows;
}

async function findById(id) {
  const r = await query(
    `SELECT r.*, u.nom AS requester_nom, p.code AS project_code, p.nom AS project_nom,
            s.code AS site_code, s.nom AS site_nom
       FROM requests r
       JOIN users u ON u.id = r.requester_id
       JOIN projects p ON p.id = r.project_id
       JOIN sites s ON s.id = r.site_id
      WHERE r.id = $1`,
    [id],
  );
  if (!r.rows[0]) return null;
  const lignes = await query(
    `SELECT rl.*, a.code AS article_code, a.designation AS article_designation
       FROM request_lines rl
       LEFT JOIN articles a ON a.id = rl.article_id
      WHERE rl.request_id = $1`,
    [id],
  );
  const approvals = await query(
    `SELECT ap.*, u.nom AS decideur_nom
       FROM approvals ap
       JOIN users u ON u.id = ap.decideur_id
      WHERE ap.request_id = $1
      ORDER BY ap.decided_at`,
    [id],
  );
  return { ...r.rows[0], lignes: lignes.rows, approvals: approvals.rows };
}

async function nextNumero() {
  const { rows } = await query(
    `SELECT COUNT(*)::int + 1 AS n FROM requests
      WHERE EXTRACT(YEAR FROM created_at) = EXTRACT(YEAR FROM now())`,
  );
  const year = new Date().getFullYear();
  return `DM-${year}-${String(rows[0].n).padStart(4, '0')}`;
}

async function create({ requester_id, project_id, site_id, urgence, motif, date_souhaitee, lignes }) {
  return withTransaction(async (c) => {
    const numero = await nextNumero();
    const r = await c.query(
      `INSERT INTO requests(numero, requester_id, project_id, site_id, statut, urgence, motif, date_souhaitee)
       VALUES ($1,$2,$3,$4,'SOUMISE',$5,$6,$7) RETURNING *`,
      [numero, requester_id, project_id, site_id, urgence, motif, date_souhaitee],
    );
    const req = r.rows[0];
    let montant = 0;
    for (const l of lignes) {
      await c.query(
        `INSERT INTO request_lines(request_id, article_id, designation_libre, qte_demandee)
         VALUES ($1,$2,$3,$4)`,
        [req.id, l.article_id || null, l.designation_libre || null, l.qte_demandee],
      );
      if (l.article_id) {
        const p = await c.query(`SELECT prix_moyen FROM articles WHERE id = $1`, [l.article_id]);
        const prix = Number(p.rows[0]?.prix_moyen || 0);
        montant += prix * Number(l.qte_demandee);
      }
    }
    await c.query(`UPDATE requests SET montant_estime = $2 WHERE id = $1`, [req.id, montant]);
    return { ...req, montant_estime: montant };
  });
}

async function addApproval({ request_id, etape, decideur_id, decision, commentaire }) {
  return withTransaction(async (c) => {
    const a = await c.query(
      `INSERT INTO approvals(request_id, etape, decideur_id, decision, commentaire)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [request_id, etape, decideur_id, decision, commentaire],
    );
    // Avancement statut simple
    let next = null;
    if (decision === 'REJETEE') next = 'REJETEE';
    else if (etape === 'TECHNIQUE' && decision === 'APPROUVEE') next = 'VALIDATION_BUDGETAIRE';
    else if (etape === 'BUDGETAIRE' && decision === 'APPROUVEE') next = 'APPROUVEE';
    else if (etape === 'DIRECTION' && decision === 'APPROUVEE') next = 'APPROUVEE';
    if (next) {
      await c.query(`UPDATE requests SET statut = $2, updated_at = now() WHERE id = $1`, [request_id, next]);
    }
    return a.rows[0];
  });
}

module.exports = { list, findById, create, addApproval };
