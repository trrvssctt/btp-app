const { z } = require('zod');
const asyncHandler = require('../utils/asyncHandler');
const validate = require('../middleware/validate');
const HttpError = require('../utils/HttpError');
const model = require('../models/requestModel');

const lineSchema = z.object({
  article_id: z.string().uuid().optional().nullable(),
  designation_libre: z.string().max(200).optional().nullable(),
  qte_demandee: z.coerce.number().positive(),
}).refine((l) => l.article_id || l.designation_libre, {
  message: 'article_id or designation_libre required',
});

const createSchema = z.object({
  project_id: z.string().uuid(),
  site_id: z.string().uuid(),
  urgence: z.enum(['NORMALE', 'URGENTE', 'CRITIQUE']),
  motif: z.string().max(500).optional().nullable(),
  date_souhaitee: z.string().optional().nullable(),
  lignes: z.array(lineSchema).min(1),
});

const approvalSchema = z.object({
  etape: z.enum(['TECHNIQUE', 'BUDGETAIRE', 'DIRECTION']),
  decision: z.enum(['APPROUVEE', 'REJETEE']),
  commentaire: z.string().max(500).optional().nullable(),
});

exports.list = asyncHandler(async (req, res) => {
  res.json({ data: await model.list(req.query) });
});

exports.get = asyncHandler(async (req, res) => {
  const r = await model.findById(req.params.id);
  if (!r) throw new HttpError(404, 'Request not found');
  res.json({ data: r });
});

exports.create = [
  validate(createSchema),
  asyncHandler(async (req, res) => {
    const r = await model.create({ ...req.body, requester_id: req.user.id });
    res.status(201).json({ data: r });
  }),
];

exports.addApproval = [
  validate(approvalSchema),
  asyncHandler(async (req, res) => {
    const requiredPerm = req.body.etape === 'TECHNIQUE' ? 'REQUEST_VALIDATE_TECH' : 'REQUEST_VALIDATE_BUDGET';
    const ok = req.user.permissions.includes(requiredPerm) || req.user.roles.includes('ADMIN');
    if (!ok) throw new HttpError(403, `Permission required: ${requiredPerm}`);

    const a = await model.addApproval({
      request_id: req.params.id,
      decideur_id: req.user.id,
      ...req.body,
    });
    res.status(201).json({ data: a });
  }),
];
