const router = require('express').Router();
const asyncHandler = require('../utils/asyncHandler');
const { authenticate } = require('../middleware/auth');
const model = require('../models/stockModel');

router.get('/', authenticate, asyncHandler(async (req, res) => {
  res.json({ data: await model.list(req.query) });
}));

module.exports = router;
