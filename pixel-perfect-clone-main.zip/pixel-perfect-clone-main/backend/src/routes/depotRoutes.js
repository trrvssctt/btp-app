const router = require('express').Router();
const asyncHandler = require('../utils/asyncHandler');
const { authenticate } = require('../middleware/auth');
const model = require('../models/depotModel');

router.get('/', authenticate, asyncHandler(async (_req, res) => {
  res.json({ data: await model.list() });
}));

module.exports = router;
