const router = require('express').Router();
const ctrl = require('../controllers/requestController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);

router.get('/', ctrl.list);
router.get('/:id', ctrl.get);
router.post('/', ctrl.create);
router.post('/:id/approvals', ctrl.addApproval);

module.exports = router;
