import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { Truck, Package, ArrowDown, ArrowUp, RotateCcw, Sliders } from "lucide-react";
import { mouvements, getArticle, getDepot } from "@/data/mock";
import { formatDateTime, mouvementLabel } from "@/data/labels";

const iconFor = (type: string) => {
  if (type.includes("ENTREE") || type === "TRANSFERT_ENTRANT") return ArrowDown;
  if (type.includes("SORTIE") || type === "TRANSFERT_SORTANT") return ArrowUp;
  if (type === "RETOUR_CHANTIER") return RotateCcw;
  if (type === "AJUSTEMENT_INVENTAIRE") return Sliders;
  return Package;
};

export default function MouvementsPage() {
  return (
    <AppLayout>
      <PageHeader
        breadcrumb="Opérations"
        title="Journal des mouvements"
        description="Traçabilité complète des entrées, sorties, transferts, retours et ajustements."
      />
      <div className="rounded-xl bg-card border border-border shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left font-medium px-4 py-3">Date</th>
              <th className="text-left font-medium px-4 py-3">Type</th>
              <th className="text-left font-medium px-4 py-3">Article</th>
              <th className="text-left font-medium px-4 py-3">Dépôt</th>
              <th className="text-right font-medium px-4 py-3">Quantité</th>
              <th className="text-left font-medium px-4 py-3">Référence</th>
              <th className="text-left font-medium px-4 py-3">Utilisateur</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {mouvements.map((m) => {
              const Icon = iconFor(m.type);
              const a = getArticle(m.articleId);
              const d = getDepot(m.depotId);
              const negative = m.type.includes("SORTIE") || m.type === "TRANSFERT_SORTANT" || (m.type === "AJUSTEMENT_INVENTAIRE" && m.quantite < 0);
              return (
                <tr key={m.id} className="hover:bg-muted/30 transition-base">
                  <td className="px-4 py-3 text-muted-foreground tabular-nums">{formatDateTime(m.date)}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Icon className={`w-4 h-4 ${negative ? "text-warning" : "text-success"}`} />
                      <span className="text-sm">{mouvementLabel[m.type]}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3"><p className="font-medium">{a?.code}</p><p className="text-xs text-muted-foreground truncate max-w-[260px]">{a?.designation}</p></td>
                  <td className="px-4 py-3 text-foreground">{d?.code}</td>
                  <td className={`px-4 py-3 text-right tabular-nums font-semibold ${negative ? "text-warning" : "text-success"}`}>
                    {negative && m.quantite > 0 ? "−" : m.quantite < 0 ? "" : "+"}{Math.abs(m.quantite)} {a?.unite}
                  </td>
                  <td className="px-4 py-3 font-mono text-xs">{m.reference}</td>
                  <td className="px-4 py-3 text-muted-foreground">{m.utilisateur}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </AppLayout>
  );
}
