import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { Wrench } from "lucide-react";
import { equipements, getChantier } from "@/data/mock";
import { NewEquipementDialog } from "@/components/dialogs/NewEquipementDialog";

const tone = (e: string) =>
  e === "DISPONIBLE" ? "success" : e === "AFFECTE" ? "info" : e === "EN_MAINTENANCE" ? "warning" : "destructive";

export default function EquipementsPage() {
  return (
    <AppLayout>
      <PageHeader
        breadcrumb="Référentiels"
        title="Parc équipements"
        description="Suivi du matériel durable : affectation, maintenance, état."
        actions={<NewEquipementDialog />}
      />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {equipements.map((e) => {
          const ch = e.chantierId ? getChantier(e.chantierId) : null;
          return (
            <div key={e.id} className="rounded-xl bg-card border border-border p-5 shadow-sm hover:shadow-elegant transition-base">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-lg bg-accent-soft text-accent flex items-center justify-center">
                  <Wrench className="w-5 h-5" />
                </div>
                <StatusBadge tone={tone(e.etat) as any}>{e.etat.replace("_", " ")}</StatusBadge>
              </div>
              <p className="font-mono text-xs text-muted-foreground mb-1">{e.code}</p>
              <p className="font-semibold text-foreground mb-3">{e.designation}</p>
              {e.affecteA && (
                <div className="text-xs text-muted-foreground space-y-0.5 pt-3 border-t border-border">
                  <p>Affecté à : <span className="text-foreground font-medium">{e.affecteA}</span></p>
                  {ch && <p>Chantier : <span className="text-foreground">{ch.nom}</span></p>}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </AppLayout>
  );
}
