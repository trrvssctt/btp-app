import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { commandes } from "@/data/mock";
import { formatDate, formatEur } from "@/data/labels";
import { NewCommandeDialog } from "@/components/dialogs/NewCommandeDialog";

const tone = (s: string) => s === "RECUE" ? "success" : s === "PARTIELLE" ? "warning" : s === "CLOTUREE" ? "muted" : s === "ENVOYEE" ? "info" : "accent";

export default function AchatsPage() {
  return (
    <AppLayout>
      <PageHeader
        breadcrumb="Approvisionnement"
        title="Achats & commandes"
        description="Consultations fournisseurs, devis, bons de commande, suivi des livraisons et reliquats."
        actions={<NewCommandeDialog />}
      />
      <div className="rounded-xl bg-card border border-border shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left font-medium px-4 py-3">Numéro</th>
              <th className="text-left font-medium px-4 py-3">Fournisseur</th>
              <th className="text-left font-medium px-4 py-3">Date</th>
              <th className="text-right font-medium px-4 py-3">Lignes</th>
              <th className="text-right font-medium px-4 py-3">Montant</th>
              <th className="text-left font-medium px-4 py-3">Statut</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {commandes.map((c) => (
              <tr key={c.id} className="hover:bg-muted/30 transition-base">
                <td className="px-4 py-3 font-mono text-xs text-accent">{c.numero}</td>
                <td className="px-4 py-3 font-medium">{c.fournisseur}</td>
                <td className="px-4 py-3 text-muted-foreground tabular-nums">{formatDate(c.date)}</td>
                <td className="px-4 py-3 text-right tabular-nums">{c.lignes}</td>
                <td className="px-4 py-3 text-right tabular-nums font-semibold">{formatEur(c.montant)}</td>
                <td className="px-4 py-3"><StatusBadge tone={tone(c.statut) as any}>{c.statut}</StatusBadge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppLayout>
  );
}
