import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, AlertTriangle } from "lucide-react";
import { articles, depots, getArticle, getDepot, stocks } from "@/data/mock";
import { formatNum, typeDepotLabel } from "@/data/labels";
import { useMemo, useState } from "react";
import { NewMouvementDialog } from "@/components/dialogs/NewMouvementDialog";

export default function StockPage() {
  const [search, setSearch] = useState("");
  const [depot, setDepot] = useState("all");

  const rows = useMemo(() => stocks.filter((s) => {
    if (depot !== "all" && s.depotId !== depot) return false;
    if (search) {
      const a = getArticle(s.articleId);
      const txt = `${a?.code} ${a?.designation}`.toLowerCase();
      if (!txt.includes(search.toLowerCase())) return false;
    }
    return true;
  }), [search, depot]);

  const totalDispo = stocks.reduce((s, x) => s + x.qteDisponible, 0);
  const totalReserve = stocks.reduce((s, x) => s + x.qteReservee, 0);
  const alertCount = stocks.filter((s) => s.qteDisponible <= s.seuilAlerte).length;

  return (
    <AppLayout>
      <PageHeader
        breadcrumb="Opérations"
        title="État du stock"
        description="Suivi multi-dépôts : magasin central, dépôts secondaires, stocks chantier."
        actions={<NewMouvementDialog />}
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="rounded-xl bg-card border border-border p-5">
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Articles référencés</p>
          <p className="text-2xl font-bold mt-1.5 tabular-nums">{articles.length}</p>
        </div>
        <div className="rounded-xl bg-card border border-border p-5">
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Total disponible</p>
          <p className="text-2xl font-bold mt-1.5 tabular-nums">{formatNum(totalDispo)} <span className="text-sm font-normal text-muted-foreground">unités</span></p>
          <p className="text-xs text-muted-foreground mt-1">Dont {formatNum(totalReserve)} réservées</p>
        </div>
        <div className="rounded-xl bg-destructive/5 border border-destructive/20 p-5">
          <p className="text-xs font-medium uppercase tracking-wider text-destructive flex items-center gap-1.5"><AlertTriangle className="w-3 h-3" /> Alertes seuil</p>
          <p className="text-2xl font-bold mt-1.5 tabular-nums text-destructive">{alertCount}</p>
        </div>
      </div>

      <div className="rounded-xl bg-card border border-border shadow-sm">
        <div className="flex flex-col lg:flex-row gap-3 p-4 border-b border-border">
          <Tabs value={depot} onValueChange={setDepot} className="lg:flex-1">
            <TabsList>
              <TabsTrigger value="all">Tous dépôts</TabsTrigger>
              {depots.map((d) => <TabsTrigger key={d.id} value={d.id}>{d.code}</TabsTrigger>)}
            </TabsList>
          </Tabs>
          <div className="relative lg:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Rechercher article…" className="pl-9 h-9" />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left font-medium px-4 py-3">Code</th>
                <th className="text-left font-medium px-4 py-3">Article</th>
                <th className="text-left font-medium px-4 py-3">Dépôt</th>
                <th className="text-right font-medium px-4 py-3">Disponible</th>
                <th className="text-right font-medium px-4 py-3">Réservé</th>
                <th className="text-right font-medium px-4 py-3">Seuil</th>
                <th className="text-left font-medium px-4 py-3">État</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {rows.map((s) => {
                const a = getArticle(s.articleId);
                const d = getDepot(s.depotId);
                const alert = s.qteDisponible <= s.seuilAlerte;
                const warn = !alert && s.qteDisponible <= s.seuilAlerte * 1.5;
                return (
                  <tr key={s.id} className="hover:bg-muted/30 transition-base">
                    <td className="px-4 py-3 font-mono text-xs">{a?.code}</td>
                    <td className="px-4 py-3"><p className="font-medium">{a?.designation}</p><p className="text-xs text-muted-foreground">{a?.famille}</p></td>
                    <td className="px-4 py-3"><p className="text-foreground">{d?.nom}</p><p className="text-xs text-muted-foreground">{typeDepotLabel[d!.type]}</p></td>
                    <td className="px-4 py-3 text-right tabular-nums font-semibold">{formatNum(s.qteDisponible)} <span className="text-muted-foreground font-normal text-xs">{a?.unite}</span></td>
                    <td className="px-4 py-3 text-right tabular-nums text-muted-foreground">{formatNum(s.qteReservee)}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-muted-foreground">{formatNum(s.seuilAlerte)}</td>
                    <td className="px-4 py-3">
                      {alert ? <StatusBadge tone="destructive">Sous seuil</StatusBadge>
                        : warn ? <StatusBadge tone="warning">Bas</StatusBadge>
                        : <StatusBadge tone="success">OK</StatusBadge>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </AppLayout>
  );
}
