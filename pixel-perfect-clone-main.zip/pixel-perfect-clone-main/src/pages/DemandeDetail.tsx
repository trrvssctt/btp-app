import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Check, X, Calendar, MapPin, User, Paperclip, MessageSquare } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { articles, demandes, getArticle, getChantier, getProjet } from "@/data/mock";
import { formatDate, formatEur, statutDemandeLabel, statutDemandeTone, urgenceTone } from "@/data/labels";

const workflow = [
  { key: "SOUMISE", label: "Soumission", role: "Demandeur" },
  { key: "VALIDATION_TECHNIQUE", label: "Validation technique", role: "Conducteur travaux" },
  { key: "VALIDATION_BUDGETAIRE", label: "Validation budgétaire", role: "Contrôleur" },
  { key: "APPROUVEE", label: "Approuvée", role: "Système" },
  { key: "MISE_A_DISPO", label: "Mise à disposition", role: "Magasinier" },
  { key: "CLOTUREE", label: "Clôturée", role: "Système" },
];

export default function DemandeDetail() {
  const { id } = useParams();
  const d = demandes.find((x) => x.id === id);

  if (!d) {
    return (
      <AppLayout>
        <p className="text-muted-foreground">Demande introuvable.</p>
        <Button asChild variant="link"><Link to="/demandes">Retour</Link></Button>
      </AppLayout>
    );
  }

  const ch = getChantier(d.chantierId);
  const pr = getProjet(d.projetId);
  const currentStepIdx = workflow.findIndex((s) => s.key === d.statut);

  return (
    <AppLayout>
      <Button asChild variant="ghost" size="sm" className="gap-1.5 mb-4 -ml-2">
        <Link to="/demandes"><ArrowLeft className="w-4 h-4" /> Retour aux demandes</Link>
      </Button>

      <PageHeader
        breadcrumb={`Demande ${d.numero}`}
        title={d.motif}
        description={`${pr?.nom} · ${ch?.nom}`}
        actions={
          <>
            <StatusBadge tone={urgenceTone[d.urgence]}>{d.urgence}</StatusBadge>
            <StatusBadge tone={statutDemandeTone[d.statut]}>{statutDemandeLabel[d.statut]}</StatusBadge>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Workflow */}
          <div className="rounded-xl bg-card border border-border shadow-sm p-5">
            <h2 className="font-semibold text-foreground mb-4">Circuit de validation</h2>
            <ol className="space-y-3">
              {workflow.map((s, i) => {
                const done = i < currentStepIdx || d.statut === "CLOTUREE";
                const current = i === currentStepIdx;
                const rejected = d.statut === "REJETEE" && i === currentStepIdx;
                return (
                  <li key={s.key} className="flex items-start gap-3">
                    <div className={`mt-0.5 w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold shrink-0 ${
                      rejected ? "bg-destructive text-destructive-foreground" :
                      done ? "bg-success text-success-foreground" :
                      current ? "bg-accent text-accent-foreground ring-4 ring-accent/20" :
                      "bg-muted text-muted-foreground"
                    }`}>
                      {rejected ? <X className="w-3.5 h-3.5" /> : done ? <Check className="w-3.5 h-3.5" /> : i + 1}
                    </div>
                    <div className="flex-1 pb-3 border-b border-border last:border-0 last:pb-0">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <p className={`text-sm font-medium ${current ? "text-foreground" : "text-muted-foreground"}`}>{s.label}</p>
                        <span className="text-xs text-muted-foreground">{s.role}</span>
                      </div>
                      {d.validations.find((v) => (v.etape === "TECHNIQUE" && s.key === "VALIDATION_TECHNIQUE") || (v.etape === "BUDGETAIRE" && s.key === "VALIDATION_BUDGETAIRE")) && (
                        <div className="mt-1.5 text-xs text-muted-foreground">
                          {(() => {
                            const v = d.validations.find((v) => (v.etape === "TECHNIQUE" && s.key === "VALIDATION_TECHNIQUE") || (v.etape === "BUDGETAIRE" && s.key === "VALIDATION_BUDGETAIRE"))!;
                            return <span>{v.valideur} · {formatDate(v.date)} {v.commentaire && `· "${v.commentaire}"`}</span>;
                          })()}
                        </div>
                      )}
                    </div>
                  </li>
                );
              })}
            </ol>
          </div>

          {/* Lignes */}
          <div className="rounded-xl bg-card border border-border shadow-sm">
            <div className="p-5 border-b border-border">
              <h2 className="font-semibold text-foreground">Articles demandés</h2>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="text-left font-medium px-4 py-2.5">Code</th>
                  <th className="text-left font-medium px-4 py-2.5">Désignation</th>
                  <th className="text-right font-medium px-4 py-2.5">Qté demandée</th>
                  <th className="text-right font-medium px-4 py-2.5">PU estimé</th>
                  <th className="text-right font-medium px-4 py-2.5">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {d.lignes.map((l) => {
                  const a = getArticle(l.articleId);
                  return (
                    <tr key={l.id}>
                      <td className="px-4 py-3 font-mono text-xs">{a?.code}</td>
                      <td className="px-4 py-3">{a?.designation}</td>
                      <td className="px-4 py-3 text-right tabular-nums">{l.quantiteDemandee} {a?.unite}</td>
                      <td className="px-4 py-3 text-right tabular-nums text-muted-foreground">{formatEur(a?.prixMoyen ?? 0)}</td>
                      <td className="px-4 py-3 text-right tabular-nums font-medium">{formatEur((a?.prixMoyen ?? 0) * l.quantiteDemandee)}</td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="bg-muted/40">
                  <td colSpan={4} className="px-4 py-3 text-right font-semibold">Total estimé</td>
                  <td className="px-4 py-3 text-right font-bold tabular-nums">{formatEur(d.montantEstime)}</td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Action panel */}
          {["SOUMISE", "VALIDATION_TECHNIQUE", "VALIDATION_BUDGETAIRE"].includes(d.statut) && (
            <div className="rounded-xl bg-gradient-to-br from-accent-soft to-card border border-accent/20 shadow-sm p-5">
              <h2 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-accent" /> Action de validation
              </h2>
              <Textarea placeholder="Commentaire optionnel (motif, conditions, substitution proposée…)" className="mb-3 bg-card" rows={3} />
              <div className="flex items-center gap-2 flex-wrap">
                <Button className="gap-1.5"><Check className="w-4 h-4" /> Approuver</Button>
                <Button variant="outline" className="gap-1.5">Demander complément</Button>
                <Button variant="outline" className="gap-1.5 text-destructive hover:text-destructive"><X className="w-4 h-4" /> Rejeter</Button>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar info */}
        <aside className="space-y-4">
          <div className="rounded-xl bg-card border border-border shadow-sm p-5 space-y-4">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Informations</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-start gap-3">
                <User className="w-4 h-4 text-muted-foreground mt-0.5" />
                <div><p className="text-xs text-muted-foreground">Demandeur</p><p className="font-medium">{d.demandeur}</p></div>
              </div>
              <div className="flex items-start gap-3">
                <Calendar className="w-4 h-4 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-xs text-muted-foreground">Date souhaitée</p>
                  <p className="font-medium">{formatDate(d.dateSouhaitee)}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-xs text-muted-foreground">Chantier</p>
                  <p className="font-medium">{ch?.nom}</p>
                  <p className="text-xs text-muted-foreground">{ch?.localisation}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-xl bg-card border border-border shadow-sm p-5">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Imputation budgétaire</h3>
            <div className="space-y-2.5 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Projet</span><span className="font-medium">{pr?.code}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Budget total</span><span className="tabular-nums">{formatEur(pr?.budget ?? 0)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Consommé</span><span className="tabular-nums">{formatEur(pr?.consomme ?? 0)}</span></div>
              <div className="h-px bg-border my-2" />
              <div className="flex justify-between font-semibold"><span>Estimé demande</span><span className="tabular-nums text-accent">{formatEur(d.montantEstime)}</span></div>
            </div>
          </div>

          <div className="rounded-xl bg-card border border-border shadow-sm p-5">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
              <Paperclip className="w-3.5 h-3.5" /> Pièces jointes
            </h3>
            <p className="text-xs text-muted-foreground">Aucune pièce jointe.</p>
          </div>
        </aside>
      </div>
    </AppLayout>
  );
}
