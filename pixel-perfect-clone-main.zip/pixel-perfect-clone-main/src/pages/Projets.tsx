import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { Progress } from "@/components/ui/progress";
import { MapPin, User, Loader2 } from "lucide-react";
import { chantiers, projets as mockProjets } from "@/data/mock";
import { formatDate, formatEur } from "@/data/labels";
import { NewProjetDialog } from "@/components/dialogs/NewProjetDialog";
import { useApiData } from "@/hooks/useApiData";
import { projectsApi } from "@/lib/api";
import { OfflineBanner } from "@/components/OfflineBanner";

type ApiProject = {
  id: string;
  code: string;
  nom: string;
  client: string | null;
  budget_initial: number | string;
  budget_consomme: number | string;
  statut: string;
  date_debut: string | null;
  date_fin: string | null;
};

export default function ProjetsPage() {
  const { data, loading, usingFallback } = useApiData<ApiProject[]>(
    () => projectsApi.list(),
    mockProjets.map((p) => ({
      id: p.id, code: p.code, nom: p.nom, client: p.client,
      budget_initial: p.budget, budget_consomme: p.consomme,
      statut: p.statut, date_debut: p.dateDebut, date_fin: p.dateFin,
    })),
    [],
  );

  return (
    <AppLayout>
      <PageHeader
        breadcrumb="Référentiels"
        title="Projets & chantiers"
        description="Vision opérationnelle et budgétaire de tous les projets en cours."
        actions={<NewProjetDialog />}
      />
      <OfflineBanner show={usingFallback} />

      {loading && <div className="text-center py-10 text-muted-foreground"><Loader2 className="w-4 h-4 animate-spin inline mr-2" />Chargement…</div>}

      <div className="space-y-6">
        {!loading && data.map((p) => {
          const budget = Number(p.budget_initial) || 0;
          const consomme = Number(p.budget_consomme) || 0;
          // Chantiers: depuis le mock si on est en fallback, sinon (en attendant l'endpoint /projects/:id) on n'affiche rien
          const chs = usingFallback ? chantiers.filter((c) => c.projetId === p.id) : [];
          const pct = budget > 0 ? (consomme / budget) * 100 : 0;
          const overrun = pct > 95;
          return (
            <div key={p.id} className="rounded-xl bg-card border border-border shadow-sm overflow-hidden">
              <div className="p-5 border-b border-border">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-xs text-muted-foreground">{p.code}</span>
                      <StatusBadge tone={p.statut === "ACTIF" ? "success" : p.statut === "CLOTURE" ? "muted" : "warning"}>{p.statut}</StatusBadge>
                    </div>
                    <h3 className="text-lg font-semibold text-foreground">{p.nom}</h3>
                    <p className="text-sm text-muted-foreground mt-0.5">
                      Client : {p.client || "—"}
                      {p.date_debut && ` · ${formatDate(p.date_debut)} → ${p.date_fin ? formatDate(p.date_fin) : "—"}`}
                    </p>
                  </div>
                  <div className="text-right min-w-[180px]">
                    <p className="text-xs uppercase tracking-wider text-muted-foreground">Consommation budget</p>
                    <p className={`text-xl font-bold tabular-nums ${overrun ? "text-destructive" : ""}`}>{Math.round(pct)}%</p>
                    <p className="text-xs text-muted-foreground tabular-nums">{formatEur(consomme)} / {formatEur(budget)}</p>
                  </div>
                </div>
                <Progress value={pct} className={`h-1.5 mt-3 ${overrun ? "[&>div]:bg-destructive" : ""}`} />
              </div>
              {chs.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-border">
                  {chs.map((c) => (
                    <div key={c.id} className="bg-card p-4 hover:bg-muted/30 transition-base">
                      <div className="flex items-center justify-between mb-1.5">
                        <p className="font-semibold text-sm">{c.nom}</p>
                        <StatusBadge tone={c.statut === "ACTIF" ? "success" : c.statut === "PAUSE" ? "warning" : "muted"}>{c.statut}</StatusBadge>
                      </div>
                      <p className="text-xs text-muted-foreground font-mono mb-3">{c.code}</p>
                      <div className="space-y-1.5 text-xs text-muted-foreground">
                        <p className="flex items-center gap-2"><MapPin className="w-3.5 h-3.5" /> {c.localisation}</p>
                        <p className="flex items-center gap-2"><User className="w-3.5 h-3.5" /> {c.responsable}</p>
                      </div>
                      <div className="mt-3">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-muted-foreground">Avancement</span>
                          <span className="font-semibold tabular-nums">{c.avancement}%</span>
                        </div>
                        <Progress value={c.avancement} className="h-1" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </AppLayout>
  );
}
