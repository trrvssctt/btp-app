import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { receptions, getDepot } from "@/data/mock";
import { formatDate } from "@/data/labels";
import { NewReceptionDialog } from "@/components/dialogs/NewReceptionDialog";

export default function ReceptionsPage() {
  return (
    <AppLayout>
      <PageHeader
        breadcrumb="Approvisionnement"
        title="Réceptions fournisseur"
        description="Bons de réception, contrôle de conformité, écarts et reliquats."
        actions={<NewReceptionDialog />}
      />
      <div className="rounded-xl bg-card border border-border shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left font-medium px-4 py-3">Numéro</th>
              <th className="text-left font-medium px-4 py-3">Date</th>
              <th className="text-left font-medium px-4 py-3">Commande</th>
              <th className="text-left font-medium px-4 py-3">Fournisseur</th>
              <th className="text-left font-medium px-4 py-3">Dépôt</th>
              <th className="text-left font-medium px-4 py-3">Receptionnaire</th>
              <th className="text-left font-medium px-4 py-3">Conformité</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {receptions.map((r) => (
              <tr key={r.id} className="hover:bg-muted/30 transition-base">
                <td className="px-4 py-3 font-mono text-xs text-accent">{r.numero}</td>
                <td className="px-4 py-3 text-muted-foreground tabular-nums">{formatDate(r.date)}</td>
                <td className="px-4 py-3 font-mono text-xs">{r.commandeNumero}</td>
                <td className="px-4 py-3 font-medium">{r.fournisseur}</td>
                <td className="px-4 py-3 text-foreground">{getDepot(r.depotId)?.code}</td>
                <td className="px-4 py-3 text-muted-foreground">{r.receptionnaire}</td>
                <td className="px-4 py-3">
                  <StatusBadge tone={r.conformite === "CONFORME" ? "success" : r.conformite === "PARTIELLE" ? "warning" : "destructive"}>
                    {r.conformite}
                  </StatusBadge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppLayout>
  );
}
