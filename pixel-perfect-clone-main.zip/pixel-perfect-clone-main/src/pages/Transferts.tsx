import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { ArrowRight } from "lucide-react";
import { NewTransfertDialog } from "@/components/dialogs/NewTransfertDialog";
import { getArticle, getDepot } from "@/data/mock";
import { formatDate } from "@/data/labels";

const transferts = [
  { id: "t1", numero: "TR-2026-0034", date: "2026-04-17", articleId: "a1", quantite: 60, emetteurId: "d1", recepteurId: "d3", statut: "RECU", emetteur: "P. Magasin", recepteur: "M. Dubois" },
  { id: "t2", numero: "TR-2026-0033", date: "2026-04-16", articleId: "a3", quantite: 30, emetteurId: "d1", recepteurId: "d2", statut: "EN_TRANSIT", emetteur: "P. Magasin", recepteur: "—" },
  { id: "t3", numero: "TR-2026-0032", date: "2026-04-15", articleId: "a5", quantite: 400, emetteurId: "d1", recepteurId: "d4", statut: "PREPARATION", emetteur: "P. Magasin", recepteur: "—" },
  { id: "t4", numero: "TR-2026-0031", date: "2026-04-14", articleId: "a9", quantite: 8, emetteurId: "d2", recepteurId: "d3", statut: "RECU", emetteur: "L. Saint-É", recepteur: "M. Dubois" },
  { id: "t5", numero: "TR-2026-0030", date: "2026-04-12", articleId: "a4", quantite: 20, emetteurId: "d1", recepteurId: "d4", statut: "LITIGE", emetteur: "P. Magasin", recepteur: "Mme Laurent" },
];

const tone = (s: string) =>
  s === "RECU" ? "success" : s === "EN_TRANSIT" ? "info" : s === "PREPARATION" ? "warning" : s === "LITIGE" ? "destructive" : "muted";

const label = (s: string) =>
  ({ RECU: "Reçu", EN_TRANSIT: "En transit", PREPARATION: "Préparation", LITIGE: "Litige" }[s] ?? s);

export default function TransfertsPage() {
  return (
    <AppLayout>
      <PageHeader
        breadcrumb="Opérations"
        title="Transferts inter-dépôts"
        description="Mouvements émetteur → récepteur avec accusé de réception obligatoire."
        actions={<NewTransfertDialog />}
      />
      <div className="rounded-xl bg-card border border-border shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left font-medium px-4 py-3">Numéro</th>
              <th className="text-left font-medium px-4 py-3">Date</th>
              <th className="text-left font-medium px-4 py-3">Article</th>
              <th className="text-right font-medium px-4 py-3">Quantité</th>
              <th className="text-left font-medium px-4 py-3">Trajet</th>
              <th className="text-left font-medium px-4 py-3">Acteurs</th>
              <th className="text-left font-medium px-4 py-3">Statut</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {transferts.map((t) => {
              const a = getArticle(t.articleId);
              const e = getDepot(t.emetteurId);
              const r = getDepot(t.recepteurId);
              return (
                <tr key={t.id} className="hover:bg-muted/30 transition-base">
                  <td className="px-4 py-3 font-mono text-xs text-accent">{t.numero}</td>
                  <td className="px-4 py-3 text-muted-foreground tabular-nums">{formatDate(t.date)}</td>
                  <td className="px-4 py-3"><p className="font-medium">{a?.code}</p><p className="text-xs text-muted-foreground truncate max-w-[220px]">{a?.designation}</p></td>
                  <td className="px-4 py-3 text-right tabular-nums font-semibold">{t.quantite} {a?.unite}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-mono">{e?.code}</span>
                      <ArrowRight className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="font-mono">{r?.code}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">
                    <p>De : <span className="text-foreground">{t.emetteur}</span></p>
                    <p>Vers : <span className="text-foreground">{t.recepteur}</span></p>
                  </td>
                  <td className="px-4 py-3"><StatusBadge tone={tone(t.statut) as any}>{label(t.statut)}</StatusBadge></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </AppLayout>
  );
}
