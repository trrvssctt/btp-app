import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { KpiCard } from "@/components/KpiCard";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowRight, AlertTriangle, FileText, HardHat, Package, TrendingUp, Truck } from "lucide-react";
import { Link } from "react-router-dom";
import { chantiers, demandes, getArticle, getChantier, getProjet, mouvements, projets, stocks } from "@/data/mock";
import { formatDateTime, formatEur, mouvementLabel, statutDemandeLabel, statutDemandeTone, urgenceTone } from "@/data/labels";
import { NewDemandeDialog } from "@/components/dialogs/NewDemandeDialog";

export default function DashboardPage() {
  const demandesEnAttente = demandes.filter((d) =>
    ["SOUMISE", "VALIDATION_TECHNIQUE", "VALIDATION_BUDGETAIRE"].includes(d.statut)
  );
  const stockAlertes = stocks.filter((s) => s.qteDisponible <= s.seuilAlerte);
  const budgetTotal = projets.reduce((s, p) => s + p.budget, 0);
  const consommeTotal = projets.reduce((s, p) => s + p.consomme, 0);
  const projetsActifs = projets.filter((p) => p.statut === "ACTIF").length;
  const chantiersActifs = chantiers.filter((c) => c.statut === "ACTIF").length;

  return (
    <AppLayout>
      <PageHeader
        breadcrumb="Vue d'ensemble"
        title="Tableau de bord opérationnel"
        description="Pilotage temps réel des chantiers, des stocks et du circuit de validation."
        actions={
          <>
            <Button variant="outline" size="sm">Exporter</Button>
            <NewDemandeDialog trigger={<Button size="sm" className="gap-1.5"><FileText className="w-4 h-4" /> Nouvelle demande</Button>} />
          </>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KpiCard label="Demandes en attente" value={demandesEnAttente.length} icon={FileText} tone="warning" hint="à valider sous 48h" />
        <KpiCard label="Alertes stock" value={stockAlertes.length} icon={AlertTriangle} tone="destructive" hint="articles sous le seuil" />
        <KpiCard label="Chantiers actifs" value={chantiersActifs} icon={HardHat} tone="accent" hint={`${projetsActifs} projets en cours`} />
        <KpiCard
          label="Consommation budget"
          value={`${Math.round((consommeTotal / budgetTotal) * 100)}%`}
          icon={TrendingUp}
          tone="success"
          hint={`${formatEur(consommeTotal)} / ${formatEur(budgetTotal)}`}
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Demandes en attente */}
        <div className="xl:col-span-2 rounded-xl bg-card border border-border shadow-sm">
          <div className="flex items-center justify-between p-5 border-b border-border">
            <div>
              <h2 className="font-semibold text-foreground">Demandes à traiter</h2>
              <p className="text-xs text-muted-foreground mt-0.5">Workflow de validation en cours</p>
            </div>
            <Button asChild variant="ghost" size="sm" className="gap-1">
              <Link to="/demandes">Tout voir <ArrowRight className="w-3.5 h-3.5" /></Link>
            </Button>
          </div>
          <div className="divide-y divide-border">
            {demandesEnAttente.slice(0, 5).map((d) => {
              const ch = getChantier(d.chantierId);
              const pr = getProjet(d.projetId);
              return (
                <Link
                  key={d.id}
                  to={`/demandes/${d.id}`}
                  className="flex items-center gap-4 p-4 hover:bg-muted/40 transition-base"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs text-muted-foreground">{d.numero}</span>
                      <StatusBadge tone={urgenceTone[d.urgence]}>{d.urgence}</StatusBadge>
                    </div>
                    <p className="text-sm font-medium text-foreground mt-1 truncate">{d.motif}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {pr?.nom} · {ch?.nom} · {d.demandeur}
                    </p>
                  </div>
                  <div className="text-right shrink-0 space-y-1">
                    <p className="text-sm font-semibold tabular-nums">{formatEur(d.montantEstime)}</p>
                    <StatusBadge tone={statutDemandeTone[d.statut]}>{statutDemandeLabel[d.statut]}</StatusBadge>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Alertes stock */}
        <div className="rounded-xl bg-card border border-border shadow-sm">
          <div className="flex items-center justify-between p-5 border-b border-border">
            <div>
              <h2 className="font-semibold text-foreground">Alertes stock</h2>
              <p className="text-xs text-muted-foreground mt-0.5">Sous seuil critique</p>
            </div>
            <Button asChild variant="ghost" size="sm" className="gap-1">
              <Link to="/stock"><ArrowRight className="w-3.5 h-3.5" /></Link>
            </Button>
          </div>
          <div className="divide-y divide-border">
            {stockAlertes.slice(0, 6).map((s) => {
              const a = getArticle(s.articleId);
              const ratio = s.qteDisponible / s.seuilAlerte;
              return (
                <div key={s.id} className="p-4 space-y-2">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{a?.designation}</p>
                      <p className="text-xs text-muted-foreground font-mono">{a?.code}</p>
                    </div>
                    <span className="text-sm font-semibold tabular-nums text-destructive shrink-0">
                      {s.qteDisponible} {a?.unite}
                    </span>
                  </div>
                  <Progress value={ratio * 100} className="h-1" />
                  <p className="text-[11px] text-muted-foreground">Seuil : {s.seuilAlerte} {a?.unite}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chantiers actifs */}
        <div className="xl:col-span-2 rounded-xl bg-card border border-border shadow-sm">
          <div className="flex items-center justify-between p-5 border-b border-border">
            <div>
              <h2 className="font-semibold text-foreground">Chantiers en cours</h2>
              <p className="text-xs text-muted-foreground mt-0.5">Avancement et responsable</p>
            </div>
            <Button asChild variant="ghost" size="sm" className="gap-1">
              <Link to="/projets">Tout voir <ArrowRight className="w-3.5 h-3.5" /></Link>
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-border">
            {chantiers.filter((c) => c.statut !== "TERMINE").slice(0, 6).map((c) => {
              const p = getProjet(c.projetId);
              return (
                <div key={c.id} className="bg-card p-4 space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold truncate">{c.nom}</p>
                      <p className="text-xs text-muted-foreground truncate">{p?.nom} · {c.responsable}</p>
                    </div>
                    <StatusBadge tone={c.statut === "ACTIF" ? "success" : "warning"}>{c.statut}</StatusBadge>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Avancement</span>
                    <span className="font-semibold tabular-nums">{c.avancement}%</span>
                  </div>
                  <Progress value={c.avancement} className="h-1.5" />
                </div>
              );
            })}
          </div>
        </div>

        {/* Mouvements récents */}
        <div className="rounded-xl bg-card border border-border shadow-sm">
          <div className="flex items-center justify-between p-5 border-b border-border">
            <div>
              <h2 className="font-semibold text-foreground">Mouvements récents</h2>
              <p className="text-xs text-muted-foreground mt-0.5">Dernières opérations</p>
            </div>
            <Truck className="w-4 h-4 text-muted-foreground" />
          </div>
          <div className="divide-y divide-border">
            {mouvements.slice(0, 5).map((m) => {
              const a = getArticle(m.articleId);
              const sortie = m.type.includes("SORTIE") || m.type === "TRANSFERT_SORTANT" || (m.type === "AJUSTEMENT_INVENTAIRE" && m.quantite < 0);
              return (
                <div key={m.id} className="p-4 flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-md flex items-center justify-center shrink-0 ${sortie ? "bg-warning-soft text-warning" : "bg-success-soft text-success"}`}>
                    {sortie ? <Truck className="w-4 h-4" /> : <Package className="w-4 h-4" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{a?.code}</p>
                    <p className="text-xs text-muted-foreground truncate">{mouvementLabel[m.type]} · {formatDateTime(m.date)}</p>
                  </div>
                  <span className={`text-sm font-semibold tabular-nums shrink-0 ${sortie ? "text-warning" : "text-success"}`}>
                    {sortie && m.quantite > 0 ? "−" : m.quantite < 0 ? "" : "+"}{Math.abs(m.quantite)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
