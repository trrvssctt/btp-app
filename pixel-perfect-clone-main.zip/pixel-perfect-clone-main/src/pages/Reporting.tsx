import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, AlertTriangle, CheckCircle2 } from "lucide-react";
import { commandes, demandes, projets, mouvements, articles } from "@/data/mock";
import { formatEur } from "@/data/labels";
import {
  Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";

const CHART_COLORS = [
  "hsl(var(--accent))",
  "hsl(var(--success))",
  "hsl(var(--warning))",
  "hsl(var(--destructive))",
  "hsl(var(--primary))",
  "hsl(var(--muted-foreground))",
];

export default function ReportingPage() {
  const totalBudget = projets.reduce((s, p) => s + p.budget, 0);
  const totalConsomme = projets.reduce((s, p) => s + p.consomme, 0);
  const validees = demandes.filter((d) => !["BROUILLON", "REJETEE"].includes(d.statut)).length;
  const tauxValidation = Math.round((validees / demandes.length) * 100);
  const totalAchats = commandes.reduce((s, c) => s + c.montant, 0);

  // Budget vs consommé par projet
  const budgetData = projets.map((p) => ({
    nom: p.nom.length > 18 ? p.nom.slice(0, 16) + "…" : p.nom,
    budget: Math.round(p.budget / 1000),
    consomme: Math.round(p.consomme / 1000),
  }));

  // Répartition statuts demandes
  const statutsData = Object.entries(
    demandes.reduce<Record<string, number>>((acc, d) => {
      acc[d.statut] = (acc[d.statut] || 0) + 1;
      return acc;
    }, {}),
  ).map(([name, value]) => ({ name, value }));

  // Top fournisseurs
  const fournisseursData = Object.entries(
    commandes.reduce<Record<string, number>>((acc, c) => {
      acc[c.fournisseur] = (acc[c.fournisseur] || 0) + c.montant;
      return acc;
    }, {}),
  )
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([nom, montant]) => ({ nom, montant: Math.round(montant / 1000) }));

  // Évolution mouvements (groupé par mois sur la base des dates)
  const moisLabels = ["Jan", "Fév", "Mar", "Avr", "Mai", "Jun"];
  const mouvementsParMois = moisLabels.map((label, idx) => {
    const inMois = mouvements.filter((m) => new Date(m.date).getMonth() === idx);
    return {
      mois: label,
      entrees: inMois.filter((m) => m.type.startsWith("ENTREE") || m.type === "TRANSFERT_ENTRANT").length,
      sorties: inMois.filter((m) => m.type.startsWith("SORTIE") || m.type === "TRANSFERT_SORTANT").length,
    };
  });

  // Top articles par valeur estimée (prixMoyen × usages)
  const articleUsage = articles
    .map((a) => {
      const total = mouvements
        .filter((m) => m.articleId === a.id)
        .reduce((s, m) => s + Math.abs(m.quantite), 0);
      return { nom: a.code, valeur: Math.round((total * a.prixMoyen) / 1000) };
    })
    .sort((a, b) => b.valeur - a.valeur)
    .slice(0, 6);

  return (
    <AppLayout>
      <PageHeader
        breadcrumb="Pilotage"
        title="Reporting & indicateurs"
        description="Tableau de bord agrégé par projet et par fournisseur."
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="rounded-xl bg-card border border-border p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-accent-soft text-accent flex items-center justify-center"><TrendingUp className="w-5 h-5" /></div>
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Engagement budgétaire</p>
              <p className="text-2xl font-bold tabular-nums">{Math.round((totalConsomme / totalBudget) * 100)}%</p>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">{formatEur(totalConsomme)} sur {formatEur(totalBudget)}</p>
        </div>
        <div className="rounded-xl bg-card border border-border p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-success-soft text-success flex items-center justify-center"><CheckCircle2 className="w-5 h-5" /></div>
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Taux de validation</p>
              <p className="text-2xl font-bold tabular-nums">{tauxValidation}%</p>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">{validees} demandes traitées sur {demandes.length}</p>
        </div>
        <div className="rounded-xl bg-card border border-border p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-warning-soft text-warning flex items-center justify-center"><AlertTriangle className="w-5 h-5" /></div>
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Volume d'achats</p>
              <p className="text-2xl font-bold tabular-nums">{formatEur(totalAchats)}</p>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">{commandes.length} commandes émises</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        <div className="rounded-xl bg-card border border-border shadow-sm p-5">
          <h2 className="font-semibold mb-4">Budget vs consommé par projet (k€)</h2>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={budgetData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="nom" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
              <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="budget" fill="hsl(var(--muted-foreground))" name="Budget" radius={[4, 4, 0, 0]} />
              <Bar dataKey="consomme" fill="hsl(var(--accent))" name="Consommé" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-xl bg-card border border-border shadow-sm p-5">
          <h2 className="font-semibold mb-4">Répartition des demandes par statut</h2>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={statutsData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={{ fontSize: 11 }}>
                {statutsData.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-xl bg-card border border-border shadow-sm p-5">
          <h2 className="font-semibold mb-4">Top fournisseurs (k€)</h2>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={fournisseursData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis type="number" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
              <YAxis type="category" dataKey="nom" width={120} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="montant" fill="hsl(var(--accent))" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-xl bg-card border border-border shadow-sm p-5">
          <h2 className="font-semibold mb-4">Mouvements de stock (entrées / sorties)</h2>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={mouvementsParMois}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="mois" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
              <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="entrees" stroke="hsl(var(--success))" strokeWidth={2} name="Entrées" />
              <Line type="monotone" dataKey="sorties" stroke="hsl(var(--warning))" strokeWidth={2} name="Sorties" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="rounded-xl bg-card border border-border shadow-sm p-5">
          <h2 className="font-semibold mb-4">Top articles consommés (valeur k€)</h2>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={articleUsage}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="nom" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
              <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="valeur" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-xl bg-card border border-border shadow-sm p-5">
          <h2 className="font-semibold mb-4">Consommation budgétaire par projet</h2>
          <div className="space-y-4">
            {projets.map((p) => {
              const pct = (p.consomme / p.budget) * 100;
              const overrun = pct > 95;
              return (
                <div key={p.id}>
                  <div className="flex items-center justify-between mb-1.5">
                    <div>
                      <p className="text-sm font-medium">{p.nom}</p>
                      <p className="text-xs text-muted-foreground">{p.client}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-bold tabular-nums ${overrun ? "text-destructive" : ""}`}>{Math.round(pct)}%</p>
                      <p className="text-xs text-muted-foreground tabular-nums">{formatEur(p.consomme)} / {formatEur(p.budget)}</p>
                    </div>
                  </div>
                  <Progress value={pct} className={`h-2 ${overrun ? "[&>div]:bg-destructive" : ""}`} />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
