import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, ShieldCheck, FileEdit, Trash2, LogIn, CheckCircle2, XCircle } from "lucide-react";
import { useMemo, useState } from "react";

type AuditAction =
  | "LOGIN"
  | "CREATE"
  | "UPDATE"
  | "DELETE"
  | "VALIDATE"
  | "REJECT"
  | "EXPORT";

interface AuditEntry {
  id: string;
  date: string;
  utilisateur: string;
  role: string;
  action: AuditAction;
  entite: string;
  reference: string;
  detail: string;
  ip: string;
}

const auditEntries: AuditEntry[] = [
  { id: "a1", date: "2026-04-21 09:14", utilisateur: "Paul Durand", role: "Conducteur travaux", action: "CREATE", entite: "Demande", reference: "DM-2026-0142", detail: "Création demande pour chantier Cèdres B", ip: "10.0.4.21" },
  { id: "a2", date: "2026-04-21 09:32", utilisateur: "Sophie Martin", role: "Responsable technique", action: "VALIDATE", entite: "Demande", reference: "DM-2026-0141", detail: "Validation technique", ip: "10.0.4.42" },
  { id: "a3", date: "2026-04-21 10:05", utilisateur: "Jean Bernard", role: "Contrôleur de gestion", action: "REJECT", entite: "Demande", reference: "DM-2026-0138", detail: "Dépassement budgétaire — motif: ligne 3", ip: "10.0.4.51" },
  { id: "a4", date: "2026-04-21 10:48", utilisateur: "Magasinier Lyon", role: "Magasinier", action: "UPDATE", entite: "Stock", reference: "ART-CIM-32.5 / MC-LYON", detail: "Ajustement inventaire -12 sacs", ip: "10.0.4.10" },
  { id: "a5", date: "2026-04-21 11:22", utilisateur: "Acheteur Central", role: "Acheteur", action: "CREATE", entite: "Commande", reference: "BC-2026-0418", detail: "Émission commande Vicat 24 500 €", ip: "10.0.4.33" },
  { id: "a6", date: "2026-04-21 12:01", utilisateur: "Sophie Martin", role: "Responsable technique", action: "EXPORT", entite: "Reporting", reference: "Engagement-Q2", detail: "Export PDF rapport trimestriel", ip: "10.0.4.42" },
  { id: "a7", date: "2026-04-21 13:17", utilisateur: "Paul Durand", role: "Conducteur travaux", action: "LOGIN", entite: "Session", reference: "—", detail: "Connexion réussie", ip: "10.0.4.21" },
  { id: "a8", date: "2026-04-21 14:03", utilisateur: "Magasinier Pont", role: "Magasinier", action: "CREATE", entite: "Réception", reference: "RC-2026-0211", detail: "Réception conforme BC-2026-0410", ip: "10.0.4.18" },
  { id: "a9", date: "2026-04-21 14:55", utilisateur: "Admin Système", role: "Administrateur", action: "UPDATE", entite: "Paramètre", reference: "Seuil validation", detail: "Seuil tech relevé 5 000 → 7 500 €", ip: "10.0.4.2" },
  { id: "a10", date: "2026-04-21 15:30", utilisateur: "Marc Lopez", role: "Chef de projet", action: "VALIDATE", entite: "Commande", reference: "BC-2026-0419", detail: "Approbation budgétaire 18 200 €", ip: "10.0.4.44" },
  { id: "a11", date: "2026-04-21 16:12", utilisateur: "Magasinier Lyon", role: "Magasinier", action: "DELETE", entite: "Mouvement", reference: "MV-2026-2014", detail: "Suppression mouvement saisi en double", ip: "10.0.4.10" },
  { id: "a12", date: "2026-04-21 16:48", utilisateur: "Paul Durand", role: "Conducteur travaux", action: "UPDATE", entite: "Demande", reference: "DM-2026-0142", detail: "Modification ligne 2 quantité 80 → 100", ip: "10.0.4.21" },
];

const actionMeta: Record<AuditAction, { label: string; icon: typeof LogIn; cls: string }> = {
  LOGIN: { label: "Connexion", icon: LogIn, cls: "bg-muted text-muted-foreground" },
  CREATE: { label: "Création", icon: FileEdit, cls: "bg-accent-soft text-accent" },
  UPDATE: { label: "Modification", icon: FileEdit, cls: "bg-warning-soft text-warning" },
  DELETE: { label: "Suppression", icon: Trash2, cls: "bg-destructive/10 text-destructive" },
  VALIDATE: { label: "Validation", icon: CheckCircle2, cls: "bg-success-soft text-success" },
  REJECT: { label: "Rejet", icon: XCircle, cls: "bg-destructive/10 text-destructive" },
  EXPORT: { label: "Export", icon: ShieldCheck, cls: "bg-muted text-muted-foreground" },
};

export default function AuditPage() {
  const [q, setQ] = useState("");
  const [action, setAction] = useState<string>("ALL");
  const [entite, setEntite] = useState<string>("ALL");

  const entites = useMemo(
    () => Array.from(new Set(auditEntries.map((a) => a.entite))),
    [],
  );

  const filtered = auditEntries.filter((a) => {
    if (action !== "ALL" && a.action !== action) return false;
    if (entite !== "ALL" && a.entite !== entite) return false;
    if (q && !`${a.utilisateur} ${a.reference} ${a.detail}`.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });

  return (
    <AppLayout>
      <PageHeader
        breadcrumb="Pilotage"
        title="Journal d'audit"
        description="Traçabilité de toutes les actions sensibles effectuées dans l'application."
      />

      <div className="rounded-xl bg-card border border-border shadow-sm">
        <div className="p-4 border-b border-border flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Rechercher utilisateur, référence, détail…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={action} onValueChange={setAction}>
            <SelectTrigger className="w-full md:w-48"><SelectValue placeholder="Action" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Toutes les actions</SelectItem>
              {Object.entries(actionMeta).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={entite} onValueChange={setEntite}>
            <SelectTrigger className="w-full md:w-48"><SelectValue placeholder="Entité" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Toutes les entités</SelectItem>
              {entites.map((e) => <SelectItem key={e} value={e}>{e}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Utilisateur</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Entité</TableHead>
                <TableHead>Référence</TableHead>
                <TableHead>Détail</TableHead>
                <TableHead className="text-right">IP</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-10 text-muted-foreground text-sm">
                    Aucune entrée ne correspond à ces filtres.
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((a) => {
                  const meta = actionMeta[a.action];
                  const Icon = meta.icon;
                  return (
                    <TableRow key={a.id}>
                      <TableCell className="text-xs tabular-nums text-muted-foreground whitespace-nowrap">{a.date}</TableCell>
                      <TableCell>
                        <div className="text-sm font-medium">{a.utilisateur}</div>
                        <div className="text-xs text-muted-foreground">{a.role}</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={`gap-1 ${meta.cls} border-transparent`}>
                          <Icon className="w-3 h-3" />
                          {meta.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">{a.entite}</TableCell>
                      <TableCell className="text-sm font-mono text-xs">{a.reference}</TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-md">{a.detail}</TableCell>
                      <TableCell className="text-right text-xs font-mono text-muted-foreground">{a.ip}</TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>

        <div className="p-3 border-t border-border text-xs text-muted-foreground text-center">
          {filtered.length} entrée{filtered.length > 1 ? "s" : ""} affichée{filtered.length > 1 ? "s" : ""} sur {auditEntries.length}
        </div>
      </div>
    </AppLayout>
  );
}
