import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, AlertTriangle, CheckCircle2, FileText, Truck, Package, Clock } from "lucide-react";
import { useState } from "react";

type NotifType = "DEMANDE" | "STOCK" | "RECEPTION" | "VALIDATION" | "TRANSFERT";

interface Notif {
  id: string;
  type: NotifType;
  titre: string;
  message: string;
  date: string;
  lu: boolean;
  urgence?: "INFO" | "WARNING" | "CRITICAL";
}

const initial: Notif[] = [
  { id: "n1", type: "VALIDATION", titre: "Demande à valider", message: "DM-2026-0142 (Cèdres B) en attente de validation technique", date: "Il y a 5 min", lu: false, urgence: "WARNING" },
  { id: "n2", type: "STOCK", titre: "Seuil d'alerte atteint", message: "Ciment CEM II 32.5 - Stock chantier Cèdres : 45 sacs (seuil 50)", date: "Il y a 22 min", lu: false, urgence: "CRITICAL" },
  { id: "n3", type: "RECEPTION", titre: "Réception confirmée", message: "RC-2026-0211 — Conforme — BC-2026-0410 cloturée", date: "Il y a 1 h", lu: false, urgence: "INFO" },
  { id: "n4", type: "DEMANDE", titre: "Demande approuvée", message: "DM-2026-0140 approuvée — passage en achat", date: "Il y a 2 h", lu: true, urgence: "INFO" },
  { id: "n5", type: "TRANSFERT", titre: "Transfert en transit", message: "TR-2026-0078 : MC Lyon → Stock Pont — ETA 16h30", date: "Il y a 3 h", lu: true },
  { id: "n6", type: "STOCK", titre: "Seuil critique", message: "Acier HA Ø16 - Dépôt St-Étienne : 12 barres (seuil 30)", date: "Hier", lu: true, urgence: "CRITICAL" },
  { id: "n7", type: "VALIDATION", titre: "Validation budgétaire requise", message: "BC-2026-0419 (18 200 €) en attente d'approbation", date: "Hier", lu: true, urgence: "WARNING" },
];

const typeIcons: Record<NotifType, typeof Bell> = {
  DEMANDE: FileText,
  STOCK: Package,
  RECEPTION: CheckCircle2,
  VALIDATION: Clock,
  TRANSFERT: Truck,
};

export default function NotificationsPage() {
  const [items, setItems] = useState(initial);
  const [tab, setTab] = useState("all");

  const filtered = items.filter((n) => {
    if (tab === "unread") return !n.lu;
    if (tab === "alerts") return n.urgence === "CRITICAL" || n.urgence === "WARNING";
    return true;
  });

  const markAllRead = () => setItems((s) => s.map((n) => ({ ...n, lu: true })));
  const toggle = (id: string) => setItems((s) => s.map((n) => (n.id === id ? { ...n, lu: !n.lu } : n)));

  const unreadCount = items.filter((n) => !n.lu).length;

  return (
    <AppLayout>
      <PageHeader
        breadcrumb="Notifications"
        title="Centre de notifications"
        description={`${unreadCount} notification${unreadCount > 1 ? "s" : ""} non lue${unreadCount > 1 ? "s" : ""}.`}
        actions={
          <Button variant="outline" size="sm" onClick={markAllRead} disabled={unreadCount === 0}>
            Tout marquer comme lu
          </Button>
        }
      />

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="all">Toutes ({items.length})</TabsTrigger>
          <TabsTrigger value="unread">Non lues ({unreadCount})</TabsTrigger>
          <TabsTrigger value="alerts">Alertes ({items.filter((n) => n.urgence === "CRITICAL" || n.urgence === "WARNING").length})</TabsTrigger>
        </TabsList>

        <TabsContent value={tab} className="space-y-2">
          {filtered.length === 0 ? (
            <div className="rounded-xl bg-card border border-border p-10 text-center">
              <Bell className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">Aucune notification dans cette catégorie.</p>
            </div>
          ) : (
            filtered.map((n) => {
              const Icon = typeIcons[n.type];
              const urgenceColor =
                n.urgence === "CRITICAL" ? "bg-destructive/10 text-destructive"
                : n.urgence === "WARNING" ? "bg-warning-soft text-warning"
                : "bg-accent-soft text-accent";
              return (
                <button
                  key={n.id}
                  onClick={() => toggle(n.id)}
                  className={`w-full text-left rounded-xl border bg-card p-4 flex gap-4 transition-base hover:border-accent/40 ${
                    !n.lu ? "border-accent/30 shadow-sm" : "border-border"
                  }`}
                >
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${urgenceColor}`}>
                    {n.urgence === "CRITICAL" ? <AlertTriangle className="w-5 h-5" /> : <Icon className="w-5 h-5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="font-medium text-sm">{n.titre}</p>
                      {!n.lu && <span className="w-1.5 h-1.5 rounded-full bg-accent" />}
                    </div>
                    <p className="text-sm text-muted-foreground">{n.message}</p>
                    <p className="text-xs text-muted-foreground/70 mt-1">{n.date}</p>
                  </div>
                </button>
              );
            })
          )}
        </TabsContent>
      </Tabs>
    </AppLayout>
  );
}
