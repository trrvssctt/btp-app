import { AppLayout } from "@/components/AppLayout";
import { PageHeader } from "@/components/PageHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Plus, Save } from "lucide-react";
import { depots } from "@/data/mock";
import { formatEur, typeDepotLabel } from "@/data/labels";
import { toast } from "sonner";

const utilisateurs = [
  { nom: "Paul Durand", email: "p.durand@btp.fr", role: "Conducteur de travaux", actif: true },
  { nom: "Marie Roche", email: "m.roche@btp.fr", role: "Contrôleur budgétaire", actif: true },
  { nom: "Jean Moreau", email: "j.moreau@btp.fr", role: "Demandeur chantier", actif: true },
  { nom: "Pierre Magasin", email: "p.magasin@btp.fr", role: "Magasinier", actif: true },
  { nom: "Claire Bernard", email: "c.bernard@btp.fr", role: "Demandeur chantier", actif: true },
  { nom: "Luc Garcia", email: "l.garcia@btp.fr", role: "Demandeur chantier", actif: false },
  { nom: "Sophie Admin", email: "admin@btp.fr", role: "Administrateur", actif: true },
];

const roles = [
  { nom: "Demandeur chantier", utilisateurs: 3, permissions: "Créer demandes, suivre statut, joindre justificatifs" },
  { nom: "Chef de chantier", utilisateurs: 2, permissions: "Créer/prioriser demandes, réceptionner chantier" },
  { nom: "Conducteur de travaux", utilisateurs: 4, permissions: "Validation technique, arbitrage stock/achat" },
  { nom: "Contrôleur budgétaire", utilisateurs: 2, permissions: "Validation budgétaire, blocage dépassement" },
  { nom: "Magasinier", utilisateurs: 3, permissions: "Mouvements, mise à disposition, réception interne" },
  { nom: "Approvisionneur", utilisateurs: 2, permissions: "Consultations, devis, BC, suivi livraison" },
  { nom: "Direction", utilisateurs: 1, permissions: "Validation engagements significatifs, escalade" },
  { nom: "Administrateur", utilisateurs: 1, permissions: "Paramétrage complet, utilisateurs, rôles, seuils" },
];

const fournisseurs = [
  { nom: "Lafarge", contact: "contact@lafarge.fr", famille: "Liants, béton", note: "A" },
  { nom: "ArcelorMittal", contact: "ventes@am.fr", famille: "Aciers", note: "A" },
  { nom: "Point P", contact: "lyon@pointp.fr", famille: "Maçonnerie, divers", note: "B" },
  { nom: "Béton Express SAS", contact: "express@beton.fr", famille: "BPE", note: "A" },
  { nom: "Sika", contact: "sika.fr@sika.com", famille: "Adjuvants", note: "A" },
  { nom: "Rexel", contact: "lyon@rexel.fr", famille: "Électricité", note: "B" },
];

const seuils = [
  { libelle: "Validation technique requise", montant: 500, escalade: "Conducteur travaux" },
  { libelle: "Validation budgétaire requise", montant: 2000, escalade: "Contrôleur budgétaire" },
  { libelle: "Validation direction requise", montant: 10000, escalade: "DAF / Direction" },
  { libelle: "Blocage dépassement budget projet", montant: 95, escalade: "Escalade automatique" },
];

export default function ParametresPage() {
  return (
    <AppLayout>
      <PageHeader
        breadcrumb="Pilotage"
        title="Paramètres"
        description="Utilisateurs, rôles, dépôts, fournisseurs et seuils de validation."
      />
      <Tabs defaultValue="users">
        <TabsList className="mb-4">
          <TabsTrigger value="users">Utilisateurs</TabsTrigger>
          <TabsTrigger value="roles">Rôles & permissions</TabsTrigger>
          <TabsTrigger value="depots">Dépôts</TabsTrigger>
          <TabsTrigger value="fournisseurs">Fournisseurs</TabsTrigger>
          <TabsTrigger value="seuils">Seuils de validation</TabsTrigger>
        </TabsList>

        <TabsContent value="users">
          <div className="rounded-xl bg-card border border-border shadow-sm">
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div>
                <h2 className="font-semibold">Comptes utilisateurs</h2>
                <p className="text-xs text-muted-foreground">{utilisateurs.length} utilisateurs · {utilisateurs.filter((u) => u.actif).length} actifs</p>
              </div>
              <Button size="sm" className="gap-1.5" onClick={() => toast.info("Formulaire utilisateur à venir")}><Plus className="w-4 h-4" /> Inviter</Button>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="text-left font-medium px-4 py-3">Nom</th>
                  <th className="text-left font-medium px-4 py-3">Email</th>
                  <th className="text-left font-medium px-4 py-3">Rôle</th>
                  <th className="text-left font-medium px-4 py-3">Statut</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {utilisateurs.map((u) => (
                  <tr key={u.email} className="hover:bg-muted/30 transition-base">
                    <td className="px-4 py-3 font-medium">{u.nom}</td>
                    <td className="px-4 py-3 text-muted-foreground">{u.email}</td>
                    <td className="px-4 py-3">{u.role}</td>
                    <td className="px-4 py-3"><StatusBadge tone={u.actif ? "success" : "muted"}>{u.actif ? "Actif" : "Désactivé"}</StatusBadge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>

        <TabsContent value="roles">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {roles.map((r) => (
              <div key={r.nom} className="rounded-xl bg-card border border-border p-5">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold">{r.nom}</h3>
                  <StatusBadge tone="accent">{r.utilisateurs}</StatusBadge>
                </div>
                <p className="text-sm text-muted-foreground">{r.permissions}</p>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="depots">
          <div className="rounded-xl bg-card border border-border shadow-sm">
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h2 className="font-semibold">Dépôts & emplacements</h2>
              <Button size="sm" className="gap-1.5" onClick={() => toast.info("Formulaire dépôt à venir")}><Plus className="w-4 h-4" /> Nouveau dépôt</Button>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="text-left font-medium px-4 py-3">Code</th>
                  <th className="text-left font-medium px-4 py-3">Nom</th>
                  <th className="text-left font-medium px-4 py-3">Type</th>
                  <th className="text-left font-medium px-4 py-3">Localisation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {depots.map((d) => (
                  <tr key={d.id} className="hover:bg-muted/30 transition-base">
                    <td className="px-4 py-3 font-mono text-xs">{d.code}</td>
                    <td className="px-4 py-3 font-medium">{d.nom}</td>
                    <td className="px-4 py-3"><StatusBadge tone="info">{typeDepotLabel[d.type]}</StatusBadge></td>
                    <td className="px-4 py-3 text-muted-foreground">{d.localisation}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>

        <TabsContent value="fournisseurs">
          <div className="rounded-xl bg-card border border-border shadow-sm">
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h2 className="font-semibold">Référentiel fournisseurs</h2>
              <Button size="sm" className="gap-1.5" onClick={() => toast.info("Formulaire fournisseur à venir")}><Plus className="w-4 h-4" /> Nouveau fournisseur</Button>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="text-left font-medium px-4 py-3">Nom</th>
                  <th className="text-left font-medium px-4 py-3">Contact</th>
                  <th className="text-left font-medium px-4 py-3">Famille</th>
                  <th className="text-left font-medium px-4 py-3">Note</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {fournisseurs.map((f) => (
                  <tr key={f.nom} className="hover:bg-muted/30 transition-base">
                    <td className="px-4 py-3 font-medium">{f.nom}</td>
                    <td className="px-4 py-3 text-muted-foreground">{f.contact}</td>
                    <td className="px-4 py-3 text-muted-foreground">{f.famille}</td>
                    <td className="px-4 py-3"><StatusBadge tone={f.note === "A" ? "success" : "warning"}>Note {f.note}</StatusBadge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>

        <TabsContent value="seuils">
          <div className="rounded-xl bg-card border border-border shadow-sm p-5 space-y-5">
            <div>
              <h2 className="font-semibold">Seuils & escalade</h2>
              <p className="text-xs text-muted-foreground">Règles automatiques de routage du workflow de validation.</p>
            </div>
            {seuils.map((s, i) => (
              <div key={i} className="grid grid-cols-1 md:grid-cols-[2fr_1fr_1fr_auto] gap-3 items-end pb-4 border-b border-border last:border-0">
                <div className="space-y-1.5"><Label className="text-xs text-muted-foreground">Règle</Label><p className="font-medium text-sm">{s.libelle}</p></div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">{i === 3 ? "Seuil (%)" : "Seuil (€)"}</Label>
                  <Input type="number" defaultValue={s.montant} className="text-right tabular-nums" />
                </div>
                <div className="space-y-1.5"><Label className="text-xs text-muted-foreground">Escalade vers</Label><p className="text-sm">{s.escalade}</p></div>
                <div className="flex items-center gap-2"><Label className="text-xs">Actif</Label><Switch defaultChecked /></div>
              </div>
            ))}
            <Button className="gap-1.5" onClick={() => toast.success("Paramètres enregistrés")}><Save className="w-4 h-4" /> Enregistrer</Button>
          </div>
        </TabsContent>
      </Tabs>
    </AppLayout>
  );
}
