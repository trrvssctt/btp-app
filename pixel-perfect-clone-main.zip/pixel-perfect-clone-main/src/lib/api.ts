import axios, { AxiosError } from "axios";

export const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000/api";
const TOKEN_KEY = "btp_token";

export const tokenStore = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t: string) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
};

export const api = axios.create({
  baseURL: API_URL,
  headers: { "Content-Type": "application/json" },
});

api.interceptors.request.use((config) => {
  const t = tokenStore.get();
  if (t) config.headers.Authorization = `Bearer ${t}`;
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (err: AxiosError<{ error?: { message?: string; details?: unknown } }>) => {
    if (err.response?.status === 401) {
      tokenStore.clear();
      if (!window.location.pathname.startsWith("/login")) {
        window.location.href = "/login";
      }
    }
    return Promise.reject(err);
  },
);

export function apiError(err: unknown): string {
  if (axios.isAxiosError(err)) {
    return err.response?.data?.error?.message || err.message || "Erreur réseau";
  }
  return (err as Error)?.message || "Erreur inconnue";
}

// --- Typed endpoints ---
export interface AuthUser {
  id: string;
  email: string;
  nom: string;
  actif: boolean;
  roles: string[];
  permissions: string[];
}

export const authApi = {
  login: (email: string, password: string) =>
    api.post<{ data: { user: AuthUser; token: string } }>("/auth/login", { email, password }).then((r) => r.data.data),
  register: (email: string, nom: string, password: string) =>
    api.post<{ data: { user: AuthUser; token: string } }>("/auth/register", { email, nom, password }).then((r) => r.data.data),
  me: () => api.get<{ data: AuthUser }>("/auth/me").then((r) => r.data.data),
};

export const projectsApi = {
  list: () => api.get<{ data: any[] }>("/projects").then((r) => r.data.data),
  get: (id: string) => api.get<{ data: any }>(`/projects/${id}`).then((r) => r.data.data),
  create: (p: any) => api.post<{ data: any }>("/projects", p).then((r) => r.data.data),
};

export const articlesApi = {
  list: (search?: string) =>
    api.get<{ data: any[] }>("/articles", { params: search ? { search } : undefined }).then((r) => r.data.data),
  create: (a: any) => api.post<{ data: any }>("/articles", a).then((r) => r.data.data),
};

export const depotsApi = {
  list: () => api.get<{ data: any[] }>("/depots").then((r) => r.data.data),
};

export const stockApi = {
  list: (params?: { depot_id?: string; article_id?: string }) =>
    api.get<{ data: any[] }>("/stock", { params }).then((r) => r.data.data),
};

export const suppliersApi = {
  list: () => api.get<{ data: any[] }>("/suppliers").then((r) => r.data.data),
};

export const requestsApi = {
  list: (params?: { statut?: string; project_id?: string }) =>
    api.get<{ data: any[] }>("/requests", { params }).then((r) => r.data.data),
  get: (id: string) => api.get<{ data: any }>(`/requests/${id}`).then((r) => r.data.data),
  create: (r: any) => api.post<{ data: any }>("/requests", r).then((res) => res.data.data),
  approve: (id: string, body: { etape: string; decision: string; commentaire?: string }) =>
    api.post<{ data: any }>(`/requests/${id}/approvals`, body).then((r) => r.data.data),
};
