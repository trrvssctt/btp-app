import type {
  Article, Chantier, Commande, Demande, Depot, Equipement,
  Mouvement, Projet, Reception, Stock,
} from "./types";

export const projets: Projet[] = [
  { id: "p1", code: "PRJ-2026-001", nom: "Résidence Les Cèdres", client: "Habitat Sud", budget: 4_850_000, consomme: 2_134_000, statut: "ACTIF", dateDebut: "2026-01-15", dateFin: "2026-12-20" },
  { id: "p2", code: "PRJ-2026-002", nom: "Pont Verdoyant", client: "Conseil Régional", budget: 12_400_000, consomme: 3_980_000, statut: "ACTIF", dateDebut: "2026-02-01", dateFin: "2027-06-30" },
  { id: "p3", code: "PRJ-2026-003", nom: "École Jean Moulin", client: "Mairie de Lyon", budget: 2_300_000, consomme: 2_120_000, statut: "ACTIF", dateDebut: "2025-09-10", dateFin: "2026-08-15" },
  { id: "p4", code: "PRJ-2025-014", nom: "Centre logistique Nord", client: "Groupe Lefort", budget: 6_700_000, consomme: 6_510_000, statut: "ACTIF", dateDebut: "2025-04-01", dateFin: "2026-05-30" },
  { id: "p5", code: "PRJ-2025-008", nom: "Rénovation Hôtel Belvédère", client: "SCI Belvédère", budget: 1_950_000, consomme: 1_950_000, statut: "CLOTURE", dateDebut: "2025-01-10", dateFin: "2025-12-01" },
];

export const chantiers: Chantier[] = [
  { id: "c1", code: "CH-001", nom: "Cèdres - Bâtiment A", projetId: "p1", localisation: "Lyon 7e", responsable: "M. Dubois", statut: "ACTIF", avancement: 62 },
  { id: "c2", code: "CH-002", nom: "Cèdres - Bâtiment B", projetId: "p1", localisation: "Lyon 7e", responsable: "M. Dubois", statut: "ACTIF", avancement: 35 },
  { id: "c3", code: "CH-003", nom: "Pont - Pile P2", projetId: "p2", localisation: "Saint-Étienne", responsable: "Mme Laurent", statut: "ACTIF", avancement: 48 },
  { id: "c4", code: "CH-004", nom: "Pont - Tablier", projetId: "p2", localisation: "Saint-Étienne", responsable: "Mme Laurent", statut: "PAUSE", avancement: 22 },
  { id: "c5", code: "CH-005", nom: "École - Gros œuvre", projetId: "p3", localisation: "Lyon 3e", responsable: "M. Petit", statut: "ACTIF", avancement: 88 },
  { id: "c6", code: "CH-006", nom: "Logistique - Dalles", projetId: "p4", localisation: "Villefranche", responsable: "M. Roux", statut: "ACTIF", avancement: 91 },
];

export const depots: Depot[] = [
  { id: "d1", code: "MC-LYON", nom: "Magasin Central Lyon", type: "MAGASIN_CENTRAL", localisation: "Lyon Vénissieux" },
  { id: "d2", code: "DS-STE", nom: "Dépôt Saint-Étienne", type: "DEPOT_SECONDAIRE", localisation: "Saint-Étienne" },
  { id: "d3", code: "SC-CH001", nom: "Stock chantier Cèdres", type: "STOCK_CHANTIER", localisation: "Lyon 7e" },
  { id: "d4", code: "SC-CH003", nom: "Stock chantier Pont", type: "STOCK_CHANTIER", localisation: "Saint-Étienne" },
];

export const articles: Article[] = [
  { id: "a1", code: "CIM-32.5", designation: "Ciment CEM II 32.5 - sac 35kg", famille: "Liants", unite: "sac", nature: "STOCKABLE", prixMoyen: 8.4 },
  { id: "a2", code: "CIM-42.5", designation: "Ciment CEM I 42.5 - sac 35kg", famille: "Liants", unite: "sac", nature: "STOCKABLE", prixMoyen: 11.2 },
  { id: "a3", code: "ACI-HA12", designation: "Acier HA Ø12 - barre 12m", famille: "Aciers", unite: "barre", nature: "STOCKABLE", prixMoyen: 18.5 },
  { id: "a4", code: "ACI-HA16", designation: "Acier HA Ø16 - barre 12m", famille: "Aciers", unite: "barre", nature: "STOCKABLE", prixMoyen: 32.8 },
  { id: "a5", code: "PAR-15", designation: "Parpaing creux 15x20x50", famille: "Maçonnerie", unite: "u", nature: "STOCKABLE", prixMoyen: 1.45 },
  { id: "a6", code: "BPE-C25", designation: "Béton prêt à l'emploi C25/30", famille: "Béton", unite: "m³", nature: "ACHAT_DIRECT", prixMoyen: 142 },
  { id: "a7", code: "GRU-LIB", designation: "Location grue à tour - jour", famille: "Engins", unite: "jour", nature: "ACHAT_DIRECT", prixMoyen: 850 },
  { id: "a8", code: "EPI-CAS", designation: "Casque chantier EN 397", famille: "EPI", unite: "u", nature: "DURABLE", prixMoyen: 24 },
  { id: "a9", code: "PEI-FAC", designation: "Peinture façade extérieure 15L", famille: "Finitions", unite: "pot", nature: "STOCKABLE", prixMoyen: 78 },
  { id: "a10", code: "TUY-PVC100", designation: "Tube PVC Ø100 - long. 4m", famille: "Plomberie", unite: "u", nature: "STOCKABLE", prixMoyen: 14.5 },
  { id: "a11", code: "CAB-3G2.5", designation: "Câble électrique 3G2.5 - couronne 100m", famille: "Électricité", unite: "couronne", nature: "STOCKABLE", prixMoyen: 89 },
  { id: "a12", code: "VIS-INOX-50", designation: "Vis inox 5x50 - boîte 200u", famille: "Quincaillerie", unite: "boîte", nature: "STOCKABLE", prixMoyen: 12.4 },
];

export const stocks: Stock[] = [
  { id: "s1", articleId: "a1", depotId: "d1", qteDisponible: 480, qteReservee: 60, seuilAlerte: 100 },
  { id: "s2", articleId: "a1", depotId: "d3", qteDisponible: 45, qteReservee: 0, seuilAlerte: 50 },
  { id: "s3", articleId: "a2", depotId: "d1", qteDisponible: 220, qteReservee: 30, seuilAlerte: 80 },
  { id: "s4", articleId: "a3", depotId: "d1", qteDisponible: 150, qteReservee: 40, seuilAlerte: 60 },
  { id: "s5", articleId: "a3", depotId: "d2", qteDisponible: 35, qteReservee: 10, seuilAlerte: 40 },
  { id: "s6", articleId: "a4", depotId: "d1", qteDisponible: 80, qteReservee: 0, seuilAlerte: 30 },
  { id: "s7", articleId: "a5", depotId: "d1", qteDisponible: 3200, qteReservee: 800, seuilAlerte: 500 },
  { id: "s8", articleId: "a5", depotId: "d3", qteDisponible: 240, qteReservee: 0, seuilAlerte: 200 },
  { id: "s9", articleId: "a8", depotId: "d1", qteDisponible: 12, qteReservee: 0, seuilAlerte: 20 },
  { id: "s10", articleId: "a9", depotId: "d1", qteDisponible: 95, qteReservee: 15, seuilAlerte: 30 },
  { id: "s11", articleId: "a10", depotId: "d1", qteDisponible: 180, qteReservee: 25, seuilAlerte: 50 },
  { id: "s12", articleId: "a11", depotId: "d2", qteDisponible: 18, qteReservee: 0, seuilAlerte: 25 },
  { id: "s13", articleId: "a12", depotId: "d1", qteDisponible: 60, qteReservee: 5, seuilAlerte: 15 },
];

export const demandes: Demande[] = [
  {
    id: "dm1", numero: "DM-2026-0142", dateDemande: "2026-04-18", dateSouhaitee: "2026-04-22",
    demandeur: "J. Moreau", chantierId: "c1", projetId: "p1", urgence: "URGENTE",
    statut: "VALIDATION_TECHNIQUE",
    motif: "Coulage dalle niveau R+2",
    lignes: [
      { id: "l1", articleId: "a1", quantiteDemandee: 80 },
      { id: "l2", articleId: "a3", quantiteDemandee: 25 },
    ],
    montantEstime: 1135,
    validations: [],
  },
  {
    id: "dm2", numero: "DM-2026-0141", dateDemande: "2026-04-17", dateSouhaitee: "2026-04-25",
    demandeur: "C. Bernard", chantierId: "c3", projetId: "p2", urgence: "NORMALE",
    statut: "VALIDATION_BUDGETAIRE",
    motif: "Reprise armature pile P2",
    lignes: [{ id: "l3", articleId: "a4", quantiteDemandee: 50 }],
    montantEstime: 1640,
    validations: [{ etape: "TECHNIQUE", valideur: "M. Laurent", date: "2026-04-18", decision: "APPROUVEE", commentaire: "Pertinent." }],
  },
  {
    id: "dm3", numero: "DM-2026-0140", dateDemande: "2026-04-17", dateSouhaitee: "2026-04-30",
    demandeur: "A. Petit", chantierId: "c5", projetId: "p3", urgence: "NORMALE",
    statut: "APPROUVEE",
    motif: "Finition façade côté cour",
    lignes: [{ id: "l4", articleId: "a9", quantiteDemandee: 30 }],
    montantEstime: 2340,
    validations: [
      { etape: "TECHNIQUE", valideur: "M. Petit", date: "2026-04-17", decision: "APPROUVEE" },
      { etape: "BUDGETAIRE", valideur: "Mme Roche", date: "2026-04-18", decision: "APPROUVEE" },
    ],
  },
  {
    id: "dm4", numero: "DM-2026-0139", dateDemande: "2026-04-16", dateSouhaitee: "2026-04-19",
    demandeur: "M. Roux", chantierId: "c6", projetId: "p4", urgence: "CRITIQUE",
    statut: "EN_ACHAT",
    motif: "Rupture béton C25/30 - coulage ce vendredi",
    lignes: [{ id: "l5", articleId: "a6", quantiteDemandee: 45 }],
    montantEstime: 6390,
    validations: [
      { etape: "TECHNIQUE", valideur: "M. Roux", date: "2026-04-16", decision: "APPROUVEE", commentaire: "Urgent." },
      { etape: "BUDGETAIRE", valideur: "Mme Roche", date: "2026-04-16", decision: "APPROUVEE" },
    ],
  },
  {
    id: "dm5", numero: "DM-2026-0138", dateDemande: "2026-04-15", dateSouhaitee: "2026-04-21",
    demandeur: "L. Garcia", chantierId: "c2", projetId: "p1", urgence: "NORMALE",
    statut: "MISE_A_DISPO",
    motif: "Cloisons étage 2",
    lignes: [{ id: "l6", articleId: "a5", quantiteDemandee: 600 }],
    montantEstime: 870,
    validations: [
      { etape: "TECHNIQUE", valideur: "M. Dubois", date: "2026-04-15", decision: "APPROUVEE" },
      { etape: "BUDGETAIRE", valideur: "Mme Roche", date: "2026-04-16", decision: "APPROUVEE" },
    ],
  },
  {
    id: "dm6", numero: "DM-2026-0137", dateDemande: "2026-04-14", dateSouhaitee: "2026-04-20",
    demandeur: "J. Moreau", chantierId: "c1", projetId: "p1", urgence: "NORMALE",
    statut: "REJETEE",
    motif: "Commande peinture intérieure",
    lignes: [{ id: "l7", articleId: "a9", quantiteDemandee: 40 }],
    montantEstime: 3120,
    validations: [
      { etape: "TECHNIQUE", valideur: "M. Dubois", date: "2026-04-15", decision: "REJETEE", commentaire: "Quantité surdimensionnée, à revoir." },
    ],
  },
  {
    id: "dm7", numero: "DM-2026-0136", dateDemande: "2026-04-14", dateSouhaitee: "2026-04-25",
    demandeur: "C. Bernard", chantierId: "c3", projetId: "p2", urgence: "NORMALE",
    statut: "SOUMISE",
    motif: "Câblage armoire technique",
    lignes: [{ id: "l8", articleId: "a11", quantiteDemandee: 8 }],
    montantEstime: 712,
    validations: [],
  },
  {
    id: "dm8", numero: "DM-2026-0135", dateDemande: "2026-04-13", dateSouhaitee: "2026-04-30",
    demandeur: "A. Petit", chantierId: "c5", projetId: "p3", urgence: "NORMALE",
    statut: "CLOTUREE",
    motif: "Quincaillerie diverse",
    lignes: [{ id: "l9", articleId: "a12", quantiteDemandee: 5 }],
    montantEstime: 62,
    validations: [
      { etape: "TECHNIQUE", valideur: "M. Petit", date: "2026-04-13", decision: "APPROUVEE" },
      { etape: "BUDGETAIRE", valideur: "Mme Roche", date: "2026-04-14", decision: "APPROUVEE" },
    ],
  },
];

export const mouvements: Mouvement[] = [
  { id: "m1", date: "2026-04-18T09:30", type: "SORTIE_CHANTIER", articleId: "a5", depotId: "d1", quantite: 600, reference: "BS-2026-0421", utilisateur: "P. Magasin", chantierId: "c2" },
  { id: "m2", date: "2026-04-18T08:15", type: "ENTREE_ACHAT", articleId: "a3", depotId: "d1", quantite: 100, reference: "REC-2026-0089", utilisateur: "P. Magasin" },
  { id: "m3", date: "2026-04-17T16:40", type: "TRANSFERT_SORTANT", articleId: "a1", depotId: "d1", quantite: 60, reference: "TR-2026-0034", utilisateur: "P. Magasin" },
  { id: "m4", date: "2026-04-17T16:40", type: "TRANSFERT_ENTRANT", articleId: "a1", depotId: "d3", quantite: 60, reference: "TR-2026-0034", utilisateur: "M. Dubois", chantierId: "c1" },
  { id: "m5", date: "2026-04-17T11:20", type: "RETOUR_CHANTIER", articleId: "a8", depotId: "d1", quantite: 4, reference: "RT-2026-0012", utilisateur: "P. Magasin", chantierId: "c5" },
  { id: "m6", date: "2026-04-16T14:00", type: "RESERVATION", articleId: "a4", depotId: "d1", quantite: 40, reference: "RSV-DM0141", utilisateur: "Système" },
  { id: "m7", date: "2026-04-16T10:30", type: "AJUSTEMENT_INVENTAIRE", articleId: "a12", depotId: "d1", quantite: -3, reference: "AJ-2026-0007", utilisateur: "P. Magasin" },
  { id: "m8", date: "2026-04-15T15:50", type: "SORTIE_CHANTIER", articleId: "a9", depotId: "d1", quantite: 12, reference: "BS-2026-0420", utilisateur: "P. Magasin", chantierId: "c5" },
];

export const commandes: Commande[] = [
  { id: "co1", numero: "BC-2026-0089", fournisseur: "Béton Express SAS", date: "2026-04-17", statut: "ENVOYEE", montant: 6390, demandeId: "dm4", lignes: 1 },
  { id: "co2", numero: "BC-2026-0088", fournisseur: "Lafarge", date: "2026-04-15", statut: "PARTIELLE", montant: 4480, lignes: 3 },
  { id: "co3", numero: "BC-2026-0087", fournisseur: "ArcelorMittal", date: "2026-04-14", statut: "RECUE", montant: 12340, lignes: 4 },
  { id: "co4", numero: "BC-2026-0086", fournisseur: "Point P", date: "2026-04-12", statut: "CLOTUREE", montant: 2890, lignes: 6 },
  { id: "co5", numero: "BC-2026-0085", fournisseur: "Rexel", date: "2026-04-10", statut: "BROUILLON", montant: 1240, lignes: 2 },
];

export const receptions: Reception[] = [
  { id: "r1", numero: "REC-2026-0089", date: "2026-04-18", commandeNumero: "BC-2026-0087", fournisseur: "ArcelorMittal", conformite: "CONFORME", depotId: "d1", receptionnaire: "P. Magasin" },
  { id: "r2", numero: "REC-2026-0088", date: "2026-04-17", commandeNumero: "BC-2026-0088", fournisseur: "Lafarge", conformite: "PARTIELLE", depotId: "d1", receptionnaire: "P. Magasin" },
  { id: "r3", numero: "REC-2026-0087", date: "2026-04-15", commandeNumero: "BC-2026-0086", fournisseur: "Point P", conformite: "RESERVE", depotId: "d2", receptionnaire: "L. Saint-É" },
  { id: "r4", numero: "REC-2026-0086", date: "2026-04-12", commandeNumero: "BC-2026-0084", fournisseur: "Sika", conformite: "CONFORME", depotId: "d1", receptionnaire: "P. Magasin" },
];

export const equipements: Equipement[] = [
  { id: "e1", code: "EQ-PERF-014", designation: "Perforateur Hilti TE60", etat: "AFFECTE", affecteA: "J. Moreau", chantierId: "c1" },
  { id: "e2", code: "EQ-NIV-008", designation: "Niveau laser Bosch GLL3", etat: "DISPONIBLE" },
  { id: "e3", code: "EQ-COMP-003", designation: "Compresseur 50L", etat: "EN_MAINTENANCE" },
  { id: "e4", code: "EQ-BET-002", designation: "Bétonnière 160L", etat: "AFFECTE", affecteA: "M. Roux", chantierId: "c6" },
];

// Helpers
export const getProjet = (id: string) => projets.find((p) => p.id === id);
export const getChantier = (id: string) => chantiers.find((c) => c.id === id);
export const getArticle = (id: string) => articles.find((a) => a.id === id);
export const getDepot = (id: string) => depots.find((d) => d.id === id);
