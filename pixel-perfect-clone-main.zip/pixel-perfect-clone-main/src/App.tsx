import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import Login from "./pages/Login.tsx";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import Demandes from "./pages/Demandes.tsx";
import DemandeDetail from "./pages/DemandeDetail.tsx";
import Stock from "./pages/Stock.tsx";
import Mouvements from "./pages/Mouvements.tsx";
import Transferts from "./pages/Transferts.tsx";
import Achats from "./pages/Achats.tsx";
import Receptions from "./pages/Receptions.tsx";
import Projets from "./pages/Projets.tsx";
import Articles from "./pages/Articles.tsx";
import Equipements from "./pages/Equipements.tsx";
import Reporting from "./pages/Reporting.tsx";
import Parametres from "./pages/Parametres.tsx";
import Audit from "./pages/Audit.tsx";
import Notifications from "./pages/Notifications.tsx";

const queryClient = new QueryClient();

const protect = (el: React.ReactNode) => <ProtectedRoute>{el}</ProtectedRoute>;

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={protect(<Index />)} />
            <Route path="/demandes" element={protect(<Demandes />)} />
            <Route path="/demandes/:id" element={protect(<DemandeDetail />)} />
            <Route path="/stock" element={protect(<Stock />)} />
            <Route path="/mouvements" element={protect(<Mouvements />)} />
            <Route path="/transferts" element={protect(<Transferts />)} />
            <Route path="/achats" element={protect(<Achats />)} />
            <Route path="/receptions" element={protect(<Receptions />)} />
            <Route path="/projets" element={protect(<Projets />)} />
            <Route path="/articles" element={protect(<Articles />)} />
            <Route path="/equipements" element={protect(<Equipements />)} />
            <Route path="/reporting" element={protect(<Reporting />)} />
            <Route path="/parametres" element={protect(<Parametres />)} />
            <Route path="/audit" element={protect(<Audit />)} />
            <Route path="/notifications" element={protect(<Notifications />)} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
