import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2 } from "lucide-react";
import { articles } from "@/data/mock";
import { formatEur } from "@/data/labels";
import { toast } from "sonner";

const fournisseurs = ["Lafarge", "ArcelorMittal", "Point P", "Béton Express SAS", "Sika", "Rexel", "Saint-Gobain"];

interface Ligne { id: string; articleId: string; quantite: string; prix: string; }

export function NewCommandeDialog({ trigger }: { trigger?: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [fournisseur, setFournisseur] = useState("");
  const [date, setDate] = useState("");
  const [lignes, setLignes] = useState<Ligne[]>([{ id: "1", articleId: "", quantite: "", prix: "" }]);

  const total = lignes.reduce((s, l) => s + (parseFloat(l.quantite) || 0) * (parseFloat(l.prix) || 0), 0);

  const submit = () => {
    if (!fournisseur || !date || lignes.some((l) => !l.articleId || !l.quantite || !l.prix)) {
      toast.error("Champs obligatoires manquants"); return;
    }
    toast.success("Bon de commande créé", { description: `Montant : ${formatEur(total)}` });
    setOpen(false);
    setFournisseur(""); setDate(""); setLignes([{ id: "1", articleId: "", quantite: "", prix: "" }]);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? <Button size="sm" className="gap-1.5"><Plus className="w-4 h-4" /> Nouvelle commande</Button>}
      </DialogTrigger>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Nouveau bon de commande</DialogTitle>
          <DialogDescription>Engagement fournisseur — réceptions partielles autorisées.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Fournisseur *</Label>
              <Select value={fournisseur} onValueChange={setFournisseur}>
                <SelectTrigger><SelectValue placeholder="Choisir…" /></SelectTrigger>
                <SelectContent>{fournisseurs.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Date commande *</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
          </div>
          <div className="border border-border rounded-lg overflow-hidden">
            <div className="flex items-center justify-between bg-muted/40 px-3 py-2 border-b border-border">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Lignes commande</p>
              <Button type="button" variant="ghost" size="sm" onClick={() => setLignes([...lignes, { id: Date.now().toString(), articleId: "", quantite: "", prix: "" }])} className="h-7 gap-1"><Plus className="w-3.5 h-3.5" /> Ligne</Button>
            </div>
            <div className="divide-y divide-border">
              {lignes.map((l) => {
                const sub = (parseFloat(l.quantite) || 0) * (parseFloat(l.prix) || 0);
                return (
                  <div key={l.id} className="grid grid-cols-12 gap-2 p-2.5 items-center">
                    <div className="col-span-5">
                      <Select value={l.articleId} onValueChange={(v) => setLignes(lignes.map((x) => x.id === l.id ? { ...x, articleId: v, prix: x.prix || (articles.find((a) => a.id === v)?.prixMoyen.toString() ?? "") } : x))}>
                        <SelectTrigger className="h-9"><SelectValue placeholder="Article…" /></SelectTrigger>
                        <SelectContent>{articles.map((a) => <SelectItem key={a.id} value={a.id}>{a.code} — {a.designation}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div className="col-span-2"><Input type="number" min="0" placeholder="Qté" value={l.quantite} onChange={(e) => setLignes(lignes.map((x) => x.id === l.id ? { ...x, quantite: e.target.value } : x))} className="h-9 text-right tabular-nums" /></div>
                    <div className="col-span-2"><Input type="number" min="0" step="0.01" placeholder="PU €" value={l.prix} onChange={(e) => setLignes(lignes.map((x) => x.id === l.id ? { ...x, prix: e.target.value } : x))} className="h-9 text-right tabular-nums" /></div>
                    <div className="col-span-2 text-right text-sm tabular-nums text-muted-foreground">{sub > 0 && formatEur(sub)}</div>
                    <div className="col-span-1 text-right">
                      <Button type="button" variant="ghost" size="icon" onClick={() => setLignes(lignes.filter((x) => x.id !== l.id))} disabled={lignes.length === 1} className="h-8 w-8 text-muted-foreground hover:text-destructive">
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center justify-between px-3 py-2.5 bg-muted/40 border-t border-border">
              <span className="text-sm font-medium">Total HT</span>
              <span className="text-base font-bold tabular-nums">{formatEur(total)}</span>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
          <Button variant="outline" onClick={() => { toast.success("Brouillon enregistré"); setOpen(false); }}>Brouillon</Button>
          <Button onClick={submit}>Émettre le BC</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
