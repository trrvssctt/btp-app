import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus } from "lucide-react";
import { articles, depots } from "@/data/mock";
import { toast } from "sonner";

export function NewMouvementDialog({ trigger }: { trigger?: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState("AJUSTEMENT_INVENTAIRE");
  const [articleId, setArticleId] = useState("");
  const [depot, setDepot] = useState("");
  const [quantite, setQuantite] = useState("");
  const [reference, setReference] = useState("");

  const submit = () => {
    if (!articleId || !depot || !quantite) { toast.error("Champs obligatoires manquants"); return; }
    toast.success("Mouvement enregistré");
    setOpen(false);
    setArticleId(""); setDepot(""); setQuantite(""); setReference("");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? <Button size="sm" className="gap-1.5"><Plus className="w-4 h-4" /> Mouvement manuel</Button>}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Mouvement manuel de stock</DialogTitle>
          <DialogDescription>Ajustement, retour ou régularisation — tracé dans l'audit.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>Type de mouvement</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="AJUSTEMENT_INVENTAIRE">Ajustement inventaire</SelectItem>
                <SelectItem value="RETOUR_CHANTIER">Retour chantier</SelectItem>
                <SelectItem value="ENTREE_ACHAT">Entrée achat</SelectItem>
                <SelectItem value="SORTIE_CHANTIER">Sortie chantier</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Article *</Label>
              <Select value={articleId} onValueChange={setArticleId}>
                <SelectTrigger><SelectValue placeholder="Choisir…" /></SelectTrigger>
                <SelectContent>{articles.map((a) => <SelectItem key={a.id} value={a.id}>{a.code}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Dépôt *</Label>
              <Select value={depot} onValueChange={setDepot}>
                <SelectTrigger><SelectValue placeholder="Choisir…" /></SelectTrigger>
                <SelectContent>{depots.map((d) => <SelectItem key={d.id} value={d.id}>{d.code}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Quantité *</Label><Input type="number" value={quantite} onChange={(e) => setQuantite(e.target.value)} className="text-right tabular-nums" placeholder="Négatif pour décrément" /></div>
            <div className="space-y-1.5"><Label>Référence</Label><Input value={reference} onChange={(e) => setReference(e.target.value)} className="font-mono" placeholder="Auto si vide" /></div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
          <Button onClick={submit}>Valider le mouvement</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
