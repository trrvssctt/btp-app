import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus } from "lucide-react";
import { toast } from "sonner";

const familles = ["Liants", "Aciers", "Maçonnerie", "Béton", "Engins", "EPI", "Finitions", "Plomberie", "Électricité", "Quincaillerie"];
const unites = ["sac", "barre", "u", "m³", "jour", "pot", "couronne", "boîte", "kg", "m", "m²"];

export function NewArticleDialog({ trigger }: { trigger?: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [code, setCode] = useState("");
  const [designation, setDesignation] = useState("");
  const [famille, setFamille] = useState("");
  const [unite, setUnite] = useState("");
  const [nature, setNature] = useState("STOCKABLE");
  const [prix, setPrix] = useState("");

  const submit = () => {
    if (!code || !designation || !famille || !unite) {
      toast.error("Champs obligatoires manquants");
      return;
    }
    toast.success("Article créé", { description: `${code} — ${designation}` });
    setOpen(false);
    setCode(""); setDesignation(""); setFamille(""); setUnite(""); setPrix(""); setNature("STOCKABLE");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? <Button size="sm" className="gap-1.5"><Plus className="w-4 h-4" /> Nouvel article</Button>}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Nouvel article</DialogTitle>
          <DialogDescription>Référencement catalogue — code unique requis.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Code *</Label>
              <Input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Ex : CIM-32.5" className="font-mono" />
            </div>
            <div className="space-y-1.5">
              <Label>Famille *</Label>
              <Select value={famille} onValueChange={setFamille}>
                <SelectTrigger><SelectValue placeholder="Choisir…" /></SelectTrigger>
                <SelectContent>{familles.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Désignation *</Label>
            <Input value={designation} onChange={(e) => setDesignation(e.target.value)} placeholder="Ex : Ciment CEM II 32.5 - sac 35kg" />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1.5">
              <Label>Unité *</Label>
              <Select value={unite} onValueChange={setUnite}>
                <SelectTrigger><SelectValue placeholder="…" /></SelectTrigger>
                <SelectContent>{unites.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Nature</Label>
              <Select value={nature} onValueChange={setNature}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="STOCKABLE">Stockable</SelectItem>
                  <SelectItem value="ACHAT_DIRECT">Achat direct</SelectItem>
                  <SelectItem value="DURABLE">Durable</SelectItem>
                  <SelectItem value="CONSOMMABLE">Consommable</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Prix moyen (€)</Label>
              <Input type="number" min="0" step="0.01" value={prix} onChange={(e) => setPrix(e.target.value)} className="text-right tabular-nums" />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
          <Button onClick={submit}>Créer l'article</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
